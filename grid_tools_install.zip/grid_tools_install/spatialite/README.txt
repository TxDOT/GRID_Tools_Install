Put these DLLs somewhere in the path for permanent spatialite access
