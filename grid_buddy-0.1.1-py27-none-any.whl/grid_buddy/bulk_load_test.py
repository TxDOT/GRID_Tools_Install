#  The MIT License (MIT)
#
#  Copyright (c) 2015 Texas Department of Transportation
#  Author: David Hickman
#
#  Permission is hereby granted, free of charge, to any person obtaining a copy
#  of this software and associated documentation files (the "Software"), to deal
#  in the Software without restriction, including without limitation the rights
#  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#  copies of the Software, and to permit persons to whom the Software is
#  furnished to do so, subject to the following conditions:
#
#  The above copyright notice and this permission notice shall be included in
#  all copies or substantial portions of the Software.
#
#  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
#  THE SOFTWARE.

import csv

from connections import create_session
from potions import *


def write_hpms_sample_update_file():
    sample_file = "C:\\__GRID__V16\\DataIssues\\HPMS_Samples_LR_Turn_Lanes\\HPMS_Samples.csv"
    update_file = "C:\\__GRID__V16\\DataIssues\\HPMS_Samples_LR_Turn_Lanes\\HPMS_SamplesUpdate.csv"

    with open(sample_file, 'rb') as read_file:
        spamreader = csv.reader(read_file, delimiter='|')
        header = next(spamreader, None)
        print header
        with open(update_file, 'wb') as write_file:
            spamwriter = csv.DictWriter(write_file, header, delimiter='|')
            source_session = create_session()
            q = source_session.query(HPMSSample.asset_id, Asset.rdbd_gmtry_ln_id, AssetLn.asset_ln_begin_dfo_ms,
                                     AssetLn.asset_ln_end_dfo_ms,
                                     HPMSSample.hpms_samp_nbr, HPMSSample.hpms_samp_begin_termnus_desc,
                                     HPMSSample.hpms_samp_end_termnus_desc, HPMSSample.hpms_samp_ret_dt,
                                     RteDefnLn.rdbd_type_id, Rte.rte_id).filter(
                HPMSSample.asset_id == AssetLn.asset_id,
                Asset.asset_id == AssetLn.asset_id,
                RteDefnLn.rdbd_gmtry_ln_id == Asset.rdbd_gmtry_ln_id,
                Rte.rte_id == RteDefnLn.rte_id,
                RteDefnLn.rte_defn_ln_prmry_flag == 1)
            spamwriter.writeheader()
            for row in q:
                r = {'RECORD_ID': row[0], 'ROUTE_ID': row[1], 'ASSET_RDBD_GMTRY_LN_ID': row[1], 'BEGIN_POINT': row[2],
                     'END_POINT': row[3], 'ASSET_RDBD_TYPE_ID': row[8], 'RTE_GRID': row[9],
                     'GRID_OP': 'DELETE'}
                spamwriter.writerow(r)


def write_roae_update_file():
    sample_file = "C:\\__GRID__V16\\DataIssues\\HPMS_Samples_LR_Turn_Lanes\\HPMS_Samples.csv"
    update_file = "C:\\__GRID__V16\\DataIssues\\HPMS_Samples_LR_Turn_Lanes\\HPMS_SamplesUpdate.csv"

    with open(sample_file, 'rb') as read_file:
        spamreader = csv.reader(read_file, delimiter='|')
        header = next(spamreader, None)
        print header
        with open(update_file, 'wb') as write_file:
            spamwriter = csv.DictWriter(write_file, header, delimiter='|')
            source_session = create_session()
            q = source_session.query(HPMSSample.asset_id, Asset.rdbd_gmtry_ln_id, AssetLn.asset_ln_begin_dfo_ms,
                                     AssetLn.asset_ln_end_dfo_ms,
                                     HPMSSample.hpms_samp_nbr, HPMSSample.hpms_samp_begin_termnus_desc,
                                     HPMSSample.hpms_samp_end_termnus_desc, HPMSSample.hpms_samp_ret_dt,
                                     RteDefnLn.rdbd_type_id, Rte.rte_id).filter(
                HPMSSample.asset_id == AssetLn.asset_id,
                Asset.asset_id == AssetLn.asset_id,
                RteDefnLn.rdbd_gmtry_ln_id == Asset.rdbd_gmtry_ln_id,
                Rte.rte_id == RteDefnLn.rte_id,
                RteDefnLn.rte_defn_ln_prmry_flag == 1)
            spamwriter.writeheader()
            for row in q:
                r = {'RECORD_ID': row[0], 'ROUTE_ID': row[1], 'ASSET_RDBD_GMTRY_LN_ID': row[1], 'BEGIN_POINT': row[2],
                     'END_POINT': row[3], 'ASSET_RDBD_TYPE_ID': row[8], 'RTE_GRID': row[9],
                     'GRID_OP': 'DELETE'}
                spamwriter.writerow(r)


def write_rmrkr_pnt_file_update():
    """
    NOTE: DO NOT CHANGE 'q', UNLESS YOU CHANGE 'r' ACCORDINGLY

    :return: None
    """
    sample_file = "C:\__GRID__V16\DataIssues\REFERENCE_MARKER_BULK_UPLOAD\ReferenceMarkerPoint.csv"
    update_file = "C:\__GRID__V16\DataIssues\REFERENCE_MARKER_BULK_UPLOAD\ReferenceMarkerPointUpdate.csv"
    with open(sample_file, 'rb') as read_file:
        spam_reader = csv.reader(read_file, delimiter='|')
        header = next(spam_reader, None)
        print header
        with open(update_file, 'wb') as write_file:
            spam_writer = csv.DictWriter(write_file, header, delimiter='|')
            source_session = create_session()
            q = source_session.query(
                ReferenceMarker.rdbd_gmtry_ln_id,
                ReferenceMarker.rmrkr_pnt_dfo_ms,
                ReferenceMarker.rmrkr_pnt_create_dt,
                ReferenceMarker.rmrkr_pnt_create_user_nm,
                ReferenceMarker.rmrkr_pnt_dfo_ms,
                ReferenceMarker.rmrkr_pnt_dt,
                ReferenceMarker.rmrkr_pnt_edit_dt,
                ReferenceMarker.rmrkr_pnt_edit_user_nm,
                ReferenceMarker.rmrkr_pnt_eff_end_dt,
                ReferenceMarker.rmrkr_pnt_eff_start_dt,
                ReferenceMarker.rmrkr_pnt_id,
                ReferenceMarker.rmrkr_pnt_lat,
                ReferenceMarker.rmrkr_pnt_lon,
                ReferenceMarker.rmrkr_pnt_nbr,
                ReferenceMarker.objectid,
                ReferenceMarker.rdbd_gmtry_ln_id,
                ReferenceMarker.rdbd_type_id,
                ReferenceMarker.rmrkr_updt_type_id,
                ReferenceMarker.rmrkr_pnt_sfx_cd,
                ReferenceMarker.stat_indctr
            )
            spam_writer.writeheader()
            record_id = 1
            for row in q:
                record_id += 1
                r = {
                    'ASSET_RDBD_GMTRY_LN_ID': row[0],
                    'BEGIN_POINT': row[1],
                    'END_POINT': 0,
                    'RMRKR_PNT_CREATE_DT': row[2],
                    'RMRKR_PNT_CREATE_USER_NM': row[3],
                    'RMRKR_PNT_DFO_MS': row[4],
                    'RMRKR_PNT_DT': row[5],
                    'RMRKR_PNT_EDIT_DT': row[6],
                    'RMRKR_PNT_EDIT_USER_NM': row[7],
                    'RMRKR_PNT_EFF_END_DT': row[8],
                    'RMRKR_PNT_EFF_START_DT': row[9],
                    'RMRKR_PNT_ID': row[10],
                    'RMRKR_PNT_LAT': row[11],
                    'RMRKR_PNT_LON': row[12],
                    'RMRKR_PNT_NBR': row[13],
                    'RMRKR_PNT_OBJECTID': row[14],
                    'RMRKR_PNT_RDBD_GMTRY_LN_ID': row[15],
                    'RMRKR_PNT_RDBD_TYPE_ID': row[16],
                    'RMRKR_PNT_RMRKR_UPDT_TYPE_ID': row[17],
                    'RMRKR_PNT_SFX_CD': row[18],
                    'RMRKR_PNT_STAT_INDCTR': row[19],
                    'RECORD_ID': record_id,
                    'ROUTE_ID': row[0],
                    'RTE_GRID': None,
                    'GRID_OP': 'REPLACE'
                }
                spam_writer.writerow(r)


if __name__ == '__main__':
    write_rmrkr_pnt_file_update()
