import os
import sys, argparse
import csv
import cx_Oracle
import sqlite3
import connections

procPath = os.path.dirname(os.path.abspath(__file__))
tables = ['ETL_JOB_SCHED','ETL_JOB_ERR','JOB_INFO', 'JOB_DATA', 'JOB_MOD','JOB_RDBD_INFO']

def get_schema(o_con, filePath):
    '''
    This method executes queries the schema for the tables, and writes to csv
    Args;
        o_con = database connection to GRID
        filePath = path to job table backup folder
    '''
    cursed = o_con.cursor()
    for table in tables:
        print('Get schema for ' + table)
        sqlFile = os.path.join(procPath, 'sql\\' + table + '.sql')
        with open(sqlFile) as f:
            sql = f.read()
        sqlCommands = sql.split(';')
        cursed.execute(sqlCommands[0])
        
        columns = [[table],['COLUMN','TYPE', 'LENGTH', 'PRECISION', 'SCALE', 'NULLABLE']]
        for desc in cursed.description:
            name = desc[0]
            cx_type = desc[1]
            name_type = desc[1].__name__
            file_length = desc[2]
            length = desc[3]
            precision = desc[4]
            scale = desc[5]
            nullable = desc[6]
            columns.append([name, name_type, length, precision, scale, nullable])
        
        if not os.path.exists(filePath + '\\schema'):
            os.makedirs(filePath + '\\schema')
        with open(filePath + '\\schema\\' + table + '.csv', 'wb') as f:
            writer = csv.writer(f)
            writer.writerows(columns)
            
    cursed.close()
    del cursed

def create_tables(s_con):
    '''
    This method will initialize the Spatialite database and create all the required tables, indexes, and key restraints.
    Args:
        s_con = database connection to SQLite backup
    '''
    print('\nCreating Tables\n') 
    s_con.enable_load_extension(True)
    s_con.load_extension('mod_spatialite.dll')
    cursed = s_con.cursor()
    print('initializing spatial metadata')
    cursed.execute('SELECT InitSpatialMetaData()')
    with open(procPath + r'\sql\CREATE_TABLES.sql') as f:
        sqlFile = f.read()
    sqlCommands = sqlFile.split(';')
    for sql in sqlCommands:
        try:
            cursed.execute(sql)
        except sqlite3.Error as e:
            print('Error creating tables:\n' + sql)
            raise e
    s_con.commit()
    cursed.close()
    del cursed
    
def fill_db(o_con, s_con):
    '''
    This method will perform and update or insert query on GRID data to fill the backup tables.
    Arguments:
        o_con = database connection to GRID
        s_con = database connection to SQLite backup
    '''
    s_con.enable_load_extension(True)
    s_con.load_extension('mod_spatialite.dll')
    o_cursed = o_con.cursor()
    s_cursed = s_con.cursor()
    for table in tables:
        sqlFile = os.path.join(procPath, 'sql\\' + table + '.sql')
        with open(sqlFile) as f:
            sqlFile = f.read()
        sqlCommands = sqlFile.split(';')

        print('executing insert/update ' + table)
        results = o_cursed.execute(sqlCommands[0])
        
        #each table type has different  DDL queries required.
        if table == 'ETL_JOB_SCHED':
            for row in results:
                s_cursed.execute(sqlCommands[1],(row[1],row[2],row[3],row[4],row[5],row[6],row[0]))
                s_cursed.execute(sqlCommands[2], row)
        elif table == 'ETL_JOB_ERR':
            for row in results:
                s_cursed.execute(sqlCommands[1],(row[1],row[2],row[3],row[4],row[5],row[6],row[0]))
                s_cursed.execute(sqlCommands[2], row)
        elif table == 'JOB_INFO':
            for row in results:
                #re-create row, turning CLOB data from Oracle into Pythoon strings; needed for SQLite insert; could not perform with SQL due to database memory constraints.
                row = (row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9],row[10],row[11],row[12],row[13],row[14],row[15],row[16],row[17],row[18],row[19],str(row[20]))
                s_cursed.execute(sqlCommands[1],(row[9],row[12],row[16],row[17],row[0]))
                s_cursed.execute(sqlCommands[2],row)
        elif table == 'JOB_DATA':
            for row in results:
                row = (row[0],row[1],row[2],row[3],row[4],str(row[5]),row[6],row[7],row[8],row[9],row[10],row[11],row[12],str(row[13]),row[14],row[15],str(row[16]),str(row[17]))
                s_cursed.execute(sqlCommands[1],(row[4], row[5], row[10], row[13], row[16], row[17], row[0]))
                s_cursed.execute(sqlCommands[2], row)
        elif table == 'JOB_MOD':
            for row in results:
                s_cursed.execute(sqlCommands[1],(row[3],row[4],row[5],row[6],row[7],row[8],row[0]))
                s_cursed.execute(sqlCommands[2], row)
        elif table == 'JOB_RDBD_INFO':
            for row in results:
                row = (row[0],row[1],row[2],row[3],row[4],row[5],str(row[6]))
                s_cursed.execute(sqlCommands[1],(row[2],row[3],row[4],row[5],row[6],row[0], row[1]))
                s_cursed.execute(sqlCommands[2], row)
        s_con.commit()
    print('Vacuuming')
    s_con.execute('VACUUM')
    o_cursed.close()
    del o_cursed
    s_cursed.close()
    del s_cursed
    
def main(filePath, db_env):
    '''
    main method will handle calls to other methods to build and fill databases
    will catch exceptions and handle database connections
    Args:
        filePath = path to job table backup folder
        db-env = GRID environment to be backed up
    '''
    if not db_env.lower() in ['prod','pre','uat']:
        print('Invalid GRID Environment; Please try again with pre, prod, or uat')
        return
    try:
        o_con = connections.grid_con(db_env)
        if not os.path.exists(filePath):
            os.makedirs(filePath)
        sqlite_db = os.path.join(filePath, 'job_tables_' + db_env + '.db')
        if not os.path.exists(sqlite_db):
            s_con = connections.sqlite_con(sqlite_db)
            try:
                get_schema(o_con,filePath)
                create_tables(s_con)
            except sqlite3.Error as e:
                s_con.close()
                os.remove(sqlite_db)
                print('Error: ' + str(e))
                return
        else:
            s_con = connections.sqlite_con(sqlite_db)
        fill_db(o_con,s_con)
        print('Update job table database ' + db_env + 'successful' )
        return sqlite_db
    except (IOError, WindowsError, cx_Oracle.Error, sqlite3.Error) as e : 
        print('Error: '  + str(e))
        return
    finally:
        o_con.close()
        s_con.close()
    
if __name__ == '__main__':
    filePath = r'C:\_GRID_BACKUP\job_tables_backup'
    parser = argparse.ArgumentParser(description='On first run this will create a backup database, and pull all current GRID jobs into tables.  On future calls, will provide UPSERT statements to update the database.  Cheers :)')
    parser.add_argument("-g", "--grid", help="backup GRID production job tables", action='store_true')
    parser.add_argument("-p", "--pre", help="backup pre-production job tables", action='store_true')
    parser.add_argument("-u", "--uat", help="backup testing job tables", action='store_true')
    args = parser.parse_args()
    
    if args.grid:
        print('Backing up GRID production job tables')
        main(filePath,'prod')   
    if args.pre:
        print('Backing up pre-production job tables')
        main(filePath,'pre')
    if args.uat:
        print('Backing up testing job tables')
        main(filePath,'uat')
    if not args.grid and not args.pre and not args.uat:
        print('\n')
        db_env = raw_input('Insert GRID environment to back up (prod, uat, pre, or all): ')
        if db_env.lower() in ['prod','uat','pre']:
            main(filePath,db_env.lower())
        elif db_env.lower() == 'all':
            main(filePath,'prod')
            main(filePath,'pre')
            main(filePath,'uat')
        else:
            print('\nThese are not the args you are looking for')
            sys.exit()