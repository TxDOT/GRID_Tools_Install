#  The MIT License (MIT)
#
#  Copyright (c) 2015 Texas Department of Transportation
#  Author: David Hickman
#
#  Permission is hereby granted, free of charge, to any person obtaining a copy
#  of this software and associated documentation files (the "Software"), to deal
#  in the Software without restriction, including without limitation the rights
#  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#  copies of the Software, and to permit persons to whom the Software is
#  furnished to do so, subject to the following conditions:
#
#  The above copyright notice and this permission notice shall be included in
#  all copies or substantial portions of the Software.
#
#  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
#  THE SOFTWARE.

from os import path
import cx_Oracle
import sqlite3
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker


class Error(Exception):
    pass


class InvalidBaseData(Error):
    def __init__(self, msg):
        self.message = msg

    def __str__(self):
        return repr(self.message)


class InvalidDataSourceError(Error):
    def __init__(self, msg):
        self.message = msg

    def __str__(self):
        return repr(self.message)

def grid_con(grid_env):
    cnx = 'app_texas_grid_rpt/semperfi@//oracle-amazon-grid' + grid_env + ':1521/GRIDDB'
    con = cx_Oracle.connect(cnx)
    return con
    
def sqlite_con(sqlite_db):
    con = sqlite3.connect(sqlite_db)
    return con

def set_grid_engine():
    """
    Create engine to connect to grid
    """
    connect_string = 'oracle://app_texas_grid_rpt:semperfi@oracle-amazon-griduat:1521/GRIDDB'
    engine = create_engine(connect_string)
    return engine


def set_local_db_engine():
    """
    Create engine to connect to local database to create mirror tables
    """
    current_directory = path.dirname(path.realpath(__file__))
    db_file = path.join(current_directory, 'GRID_Local_Mirror_Tables.db')
    connect_string = 'sqlite:///{0}'.format(db_file.encode('string-escape'))
    engine = create_engine(connect_string)
    return engine


def create_session(source='grid'):
    if source not in ['grid', 'local']:
        raise InvalidDataSourceError

    elif source == 'local':
        engine = set_local_db_engine()

    else:
        engine = set_grid_engine()

    session_maker = sessionmaker(bind=engine)
    session = session_maker()
    return session
