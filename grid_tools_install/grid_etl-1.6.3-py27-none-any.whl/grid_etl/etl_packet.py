"""
The MIT License (MIT)

Copyright (c) 2015 Texas Department of Transportation

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

"""

# Python imports
import gdal_env
import logging
import os
import subprocess
import time
import datetime
import argparse


import arcpy
import yaml
from arcpy import env

import etl_config
from etl_database.apothecary import update_db_multiple
from etl_db import start_db
from etl_util import *

# ETL_Roadways class
class _EtlJob(object):
    job = etree.Element('job')

    def __init__(self, description=None):
        """
        Initializes an xml object

        :param description: description of the ETL job -- not currently implemented
        :return: None
        """
        self.id = str(int(time.time()))
        self.description = description
        self.task_id = 0
        self.job = etree.Element('job')
        self.job.set("id", str(self.id))
        self.job.set("{http://www.w3.org/2001/XMLSchema-instance}" + "noNamespaceSchemaLocation",
                     "../xml_schema/ETL_Roadways.xsd")
        if description is not None:
            self.desc = etree.SubElement(self.job, "description")
            self.desc.text = description

    def add_task(self, ngeoms_list, ogeoms_list=None):
        """
        Add task for ETL job

        :param ngeoms_list: list of new geometry GID's
        :param ogeoms_list: list of old geometry GID's
        :return: None
        """
        self.task_id += 1
        task = etree.SubElement(self.job, "task")
        task.set("id", str(self.task_id))
        task.set("type", "Add")
        self.ngeom(task, ngeoms_list)
        if ogeoms_list is not None:
            self.ogeom(task, ogeoms_list)

    def retire_task(self, geoms_list=None):
        """
        Retire task for ETL job

        :param geoms_list: list of all GID's associated with ETL job
        :return: None
        """
        self.task_id += 1
        task = etree.SubElement(self.job, "task")
        task.set("id", str(self.task_id))
        task.set("type", "Retire")
        if geoms_list is not None:
            self.ogeom(task, geoms_list)

    def ngeom(self, task, ngeoms_list):
        """
        New Geometry Method

        :param task:
        :param ngeoms_list:
        :return: None
        """
        for g in ngeoms_list:
            ngeom = etree.SubElement(task, "ngeom")
            for k, v in g.iteritems():
                if k == 'coordExtents':
                    self.coord_extents(ngeom, v)
                else:
                    ngeom.set(str(k), str(v))

    def ogeom(self, task, ogeoms_list):
        """
        Old Geometry Method

        :param task:
        :param ogeoms_list:
        :return: None
        """
        for g in ogeoms_list:
            ogeom = etree.SubElement(task, "ogeom")
            for k, v in g.iteritems():
                if k == 'coordExtents':
                    self.coord_extents(ogeom, v)
                else:
                    ogeom.set(str(k), str(v))

    def coord_extents(self, geom, coord_dictionary):
        """
        Method for entering the coordinate extents of the modified segment

        :param geom:
        :param coord_dictionary:
        :return: None
        """
        coord_extents = etree.SubElement(geom, "coord_extents")
        for k, v in coord_dictionary.iteritems():
            coord_extents.set(str(k), str(v))

    def pretty_print(self):
        """
        Prints formatted xml to the command line

        :return: None
        """
        print(etree.tostring(self.job, pretty_print=True))

    def write_out(self, folder_path):
        """
        Writes XML to output file

        :param folder_path: output folder path from the config key/value pair
        :return: None
        """

        etree.ElementTree(self.job).write(os.path.join(folder_path, "ETL_Roadways.xml"))


# RouteDefinitionLine class
class _EtlRouteDefnLn(object):
    """ Initializes the XML document """

    def __init__(self):
        self.route_defn = etree.Element('routeDefinitionLines')
        self.route_defns = etree.Element('routeDefinitionLines')
        self.route_defn.set("{http://www.w3.org/2001/XMLSchema-instance}" + "noNamespaceSchemaLocation",
                            "../xml_schema/RouteDefinitionLine.xsd")

    # add_route method accepts a dictionary of route attributes passed
    # as a dictionary from the cursor in create_xml
    def add_route(self, rte_attrs):
        route_defn_ln = etree.SubElement(self.route_defn, 'routeDefinitionLine')
        for attribute in ['routeDefinitionLineId', 'roadbedGeometryLineId', 'routeId', 'measure', 'roadbedTypeId',
                          'cardinalDirectionTypeId', 'routeDefinitionTypeId', 'name', 'primaryFlag',
                          'mileageReversedFlag', 'beginLatitude', 'beginLongitude', 'endLatitude', 'endLongitude',
                          'editDate', 'editUserName', 'createDate', 'createUserName', 'effectiveStartDate', 'objectid',
                          'beginDfoMeasure', 'endDfoMeasure']:
            if rte_attrs[attribute] is not None and rte_attrs[attribute] != 'None':
                sub_ele = etree.SubElement(route_defn_ln, attribute)
                sub_ele.text = str(rte_attrs[attribute])

    def pretty_print(self):
        """ Formatted print method """
        print(etree.tostring(self.route_defn, pretty_print=True))

    def write_out(self, folder_path):
        """ Write to xml document method """
        path = os.path.join(folder_path, "RouteDefinitionLine.xml")
        etree.ElementTree(self.route_defn).write(path)


# Route class
class _EtlRoute(object):
    """ Initializes the XML document """

    def __init__(self):
        self.route = etree.Element('routes')
        self.routes = etree.Element('routes')
        self.route.set("{http://www.w3.org/2001/XMLSchema-instance}" + "noNamespaceSchemaLocation",
                       "../xml_schema/Routes.xsd")

    # add_route method accepts a dictionary of route attributes passed
    # as a dictionary from the cursor in create_xml
    def add_route(self, rte_attrs):
        routes_ = etree.SubElement(self.route, 'route')
        for attribute in \
                [
                    'routeId',
                    'number',
                    'routePrefixTypeId',
                    'routeSuffixTypeId',
                    'effectiveStartDate',
                    'countyTypeNumber',
                    'opType'
                ]:
            if rte_attrs[attribute] is not None and rte_attrs[attribute] != 'None':
                sub_ele = etree.SubElement(routes_, attribute)
                sub_ele.text = str(rte_attrs[attribute])

    def pretty_print(self):
        """ Formatted print method """
        print(etree.tostring(self.route, pretty_print=True))

    def write_out(self, folder_path):
        """ Write to xml document method """
        path = os.path.join(folder_path, "Routes.xml")
        etree.ElementTree(self.route).write(path)


def etl(job_limit=None, debug=False, start_server=True):
    """
    This is the primary function for creating an etl job

    :param job_limit: Limits the jobs run to a specific list of jobs
    :param debug: Prevents automatic deletion of temp job files
    :param start_server: Starts the flask server to view the success failure of an ETL packet creation
    :return None
    """
    
    start_time_datetime = datetime.datetime.now()
    beg_time = time.ctime()

    session_dictionary = {}

    start_time = time.localtime()
    time_string = "{0}_{1}_{2}_{3}_{4}_{5}".format(start_time.tm_mon, start_time.tm_mday, start_time.tm_year,
                                                   start_time.tm_hour, start_time.tm_min, start_time.tm_sec)

    current_directory = os.path.dirname(os.path.realpath(__file__))
    config_file = os.path.join(current_directory, 'etl_config_resources\\etl_config_paths.yml')

    if not os.path.exists(config_file):
        etl_config.config()
        print "\nContinuing with grid_etl."

    xsd_file_directory = os.path.join(current_directory, 'etl_config_resources\\etl_xsd')

    # Open and read configuration file
    with open(config_file, 'r') as ymlfile:
        cfg = yaml.load(ymlfile)

    log_directory = os.path.join(cfg["paths"]["output_location"], 'etl_logs')

    if not os.path.exists(log_directory):
        os.makedirs(log_directory)

    log_file = os.path.join(log_directory, "EtlLog_" + time_string + ".log")

    logging.basicConfig(filename=log_file, level=logging.DEBUG)

    # Configuration logging info
    logging.info("\n\n")
    logging.info("***********************************************************")
    logging.info("Began: " + beg_time)
    logging.info("\n")
    logging.info("Configuration file loaded...")
    logging.info("xsd File Location: " + xsd_file_directory)
    logging.info("Feature Class: " + cfg["paths"]["features"])
    logging.info("Output Location: " + cfg["paths"]["output_location"])
    logging.info("***********************************************************")
    logging.info("\n\n")

    def create_xml(input_table, output_path, add_routes, retire_routes, adds_list, retires_list, terminal_coords=None):
        """
        Creates xml from in_memory feature class

        :param input_table:
        :param output_path:
        :param add_routes:
        :param retire_routes:
        :param adds_list:
        :param retires_list:
        :param terminal_coords:
        :return:
        """
		
        job_id = str(os.path.basename(input_table).split(".")[0])

        route_attrs = {
            'routeDefinitionLineId': None,
            'roadbedGeometryLineId': None,
            'routeId': None,
            'measure': None,
            'roadbedTypeId': None,
            'cardinalDirectionTypeId': None,
            'routeDefinitionTypeId': None,
            'name': None,
            'primaryFlag': None,
            'mileageReversedFlag': None,
            'beginLatitude': None,
            'beginLongitude': None,
            'endLatitude': None,
            'endLongitude': None,
            'editDate': None,
            'editUserName': None,
            'createDate': None,
            'createUserName': None,
            'effectiveStartDate': None,
            'rte_effectiveStartDate': None,
            'objectid': None,
            'beginDfoMeasure': None,
            'endDfoMeasure': None,
            'number': None,
            'routePrefixTypeId': None,
            'routeSuffixTypeId': None,
            'countyTypeNumber': None,
            'opType': None
        }

        supplemental_query = " \"ETL_JOB_ID\" = '{0}'".format(os.path.basename(input_table).split("_")[1])
        logging.info("{0} - {1}".format(input_table, supplemental_query))

        sr = arcpy.SpatialReference(4269)
        route_rows = arcpy.SearchCursor(dataset=input_table,
                                        where_clause=supplemental_query,
                                        spatial_reference=sr,
                                        sort_fields="EDIT_TYPE A")

        shape_name = arcpy.Describe(input_table).shapeFieldName
		# Initialize route object if there are added or retired routes
        if len(add_routes) or len(retire_routes):
            route_xml_obj = _EtlRoute()
            logging.info("{0}...Initializing Route Object".format(job_id))
        else:
            route_xml_obj = None
        route_defn_ln_xml_obj = None
        etl_roadways_obj = _EtlJob("Description Placeholder")

        route_defn_ln_xml_validate = True
        route_xml_validate = True
		
        for route_row in route_rows:

            # Route Definition Line Attrs
            route_attrs['routeDefinitionLineId'] = int(route_row.GID)

            route_attrs['roadbedGeometryLineId'] = int(route_row.GID)

            route_attrs['routeId'] = int(route_row.RTE_GRID)

            route_attrs['measure'] = str(round(route_row.SEG_LEN, 3))

            route_attrs['roadbedTypeId'] = str(route_row.RDBD_TYPE)

            route_attrs['cardinalDirectionTypeId'] = str(route_row.DES_DRCT)

            route_attrs['routeDefinitionTypeId'] = str(1)

            route_attrs['name'] = str(route_row.RTE_RB_NM)

            route_attrs['primaryFlag'] = str(1)

            route_attrs['mileageReversedFlag'] = str(0)

            route_attrs['beginLatitude'] = get_first_y(route_row.getValue(shape_name))

            route_attrs['beginLongitude'] = get_first_x(route_row.getValue(shape_name))

            route_attrs['endLatitude'] = get_last_y(route_row.getValue(shape_name))

            route_attrs['endLongitude'] = get_last_x(route_row.getValue(shape_name))

            create_date = str(route_row.CREATE_DT)
            create_date_formatted = create_date.split()[0]

            edit_date = str(route_row.EDIT_DT)
            edit_date_formatted = edit_date.split()[0]

            create_name = 'TPP'

            logging.info("{0} - {1}".format(create_date, create_name))

            route_attrs['editDate'] = edit_date_formatted

            route_attrs['editUserName'] = str(route_row.EDIT_NM)

            route_attrs['createDate'] = create_date_formatted

            route_attrs['createUserName'] = str(route_row.CREATE_NM)

            route_attrs['effectiveStartDate'] = create_date_formatted

            route_attrs['objectid'] = str(int(route_row.GID))

            route_attrs['beginDfoMeasure'] = get_first_m(route_row.getValue(shape_name))

            route_attrs['endDfoMeasure'] = get_last_m(route_row.getValue(shape_name))

            # Route Attrs
            route_attrs['routeId'] = int(route_row.RTE_GRID)

            route_attrs['number'] = str(route_row.RTE_NBR)

            route_attrs['routePrefixTypeId'] = str(route_row.RTE_PRFX)

            route_attrs['routeSuffixTypeId'] = str(route_row.RTE_SFX)

            route_attrs['rte_effectiveStartDate'] = create_date_formatted

            route_attrs['countyTypeNumber'] = str(route_row.COUNTY)

            route_attrs['opType'] = str(route_row.EDIT_TYPE).split()[0]

            if route_row.RTE_GRID in add_routes:
                route_attrs['effectiveStartDate'] = route_attrs['rte_effectiveStartDate']
                route_xml_obj.add_route(route_attrs)
                logging.info("{0}...Adding Route {1} gid: {2} \
                    to Route".format(job_id, route_attrs['name'], route_attrs['roadbedGeometryLineId']))
                add_routes.remove(route_row.RTE_GRID)

            elif route_row.RTE_GRID in retire_routes:
                route_attrs['effectiveStartDate'] = route_attrs['rte_effectiveStartDate']
                route_xml_obj.add_route(route_attrs)
                logging.info("{0}...Adding Route {1} gid: {2} \
                    to Route".format(job_id, route_attrs['name'], route_attrs['roadbedGeometryLineId']))
                retire_routes.remove(route_row.RTE_GRID)

            # Add task to _EtlJob and add item to Route_defn_ln_xml_obj
            if route_attrs['opType'].split()[0] == 'Retire':

                etl_roadways_obj.retire_task([{'gid': route_attrs['roadbedGeometryLineId'], 'roadwayStatus': '99'}])

            elif route_attrs['opType'].split()[0] == 'Add':

                if route_row.getValue("OGEOMS") and route_row.getValue("OGEOMS").strip():
                    try:
                        ogeoms_split = route_row.getValue("OGEOMS").split(",")
                        ogeoms = [int(str(og).strip()) for og in ogeoms_split]

                        if set(ogeoms).issubset(set(retires_list)):
                            ogeoms_list = [{'gid': og, 'roadwayStatus': '99'} for og in ogeoms]
                            etl_roadways_obj.add_task(
                                [{'gid': route_attrs['roadbedGeometryLineId'],
                                  'roadwayStatus': '99'}], ogeoms_list)
                        else:
                            raise InvalidOldGIDList(route_attrs['roadbedGeometryLineId'], ogeoms, retires_list)
                    except:
                        raise InvalidOldGIDListFormatting(route_attrs['roadbedGeometryLineId'])
                else:
                    etl_roadways_obj.add_task([{'gid': route_attrs['roadbedGeometryLineId'], 'roadwayStatus': '99'}])

                if route_defn_ln_xml_obj is None:
                    route_defn_ln_xml_obj = _EtlRouteDefnLn()
                    logging.info("{0}...Creating RouteDefinitionLine Object".format(job_id))

                route_defn_ln_xml_obj.add_route(route_attrs)
                logging.info("{0}...Adding Route {1} gid: {2} in "
                             "RouteDefinitionLine"
                             .format(job_id, route_attrs['name'], route_attrs['roadbedGeometryLineId']))
            else:
                print "Grid Op Type Error"
                logging.warning("{0}...GRIDOP TYPE {1} IS NOT ALLOWED".format(job_id, route_attrs['opType']))

            logging.info("{0}...Creating {1} Task {2} gid: {3} in \
                ETL_Roadways".format(job_id, route_attrs['opType'], route_attrs['name'], route_attrs[
                'roadbedGeometryLineId']))

        # Validate routes.xml
        if route_xml_obj:
            route_xml_obj.write_out(output_path)

            logging.info("{0}...Writing routes.xml".format(job_id))

            del route_xml_obj

            route_xml_validate = validate_xml(
                os.path.join(xsd_file_directory, "Routes.xsd"), os.path.join(output_path, 'routes.xml'))

            if route_xml_validate is not True:
                logging.warning("{0}...routes.xml IS NOT VALID".format(job_id))
                logging.warning("{0}...{1}".format(job_id, route_xml_validate))
                route_xml_validate = False

            else:
                logging.info("{0}...routes.xml is Valid".format(job_id))

        # Write RouteDefinitionLine.xml
        if route_defn_ln_xml_obj is not None:
            route_defn_ln_xml_obj.write_out(output_path)

            logging.info("{0}...Writing RouteDefinitionLine.xml".format(job_id))

            del route_defn_ln_xml_obj

            route_defn_ln_xml_validate = validate_xml(
                os.path.join(xsd_file_directory,
                             "RouteDefinitionLine.xsd"), os.path.join(output_path, 'RouteDefinitionLine.xml'))

            if route_defn_ln_xml_validate is not True:
                logging.warning("{0}...RouteDefinitionLine.xml IS NOT VALID".format(job_id))

                logging.warning("{0}...{1}".format(job_id, route_defn_ln_xml_validate))
                route_defn_ln_xml_validate = False

            else:
                logging.info("{0}...RouteDefinitionLine.xml is Valid".format(job_id))

        # Write ETL_Roadways
        etl_roadways_obj.write_out(output_path)

        logging.info("{0}...Writing ETL_Roadways.xml".format(job_id))

        del etl_roadways_obj

        etl_roadways_validate = validate_xml(
            os.path.join(xsd_file_directory, "ETL_Roadways.xsd"), os.path.join(output_path, 'ETL_Roadways.xml'))

        if etl_roadways_validate is not True:
            logging.warning("{0}...ETL_Roadways.xml IS NOT VALID".format(job_id))
            etl_roadways_validate = False
        else:
            logging.info("{0}...ETL_Roadways.xml is Valid".format(job_id))

        if route_xml_validate is True \
                and route_defn_ln_xml_validate is True \
                and etl_roadways_validate is True:
            return True
        else:
            return False

    def create_gml(input_features_path, input_features_name, output_path):
        """
        Create output ETL package for GRID

        :param input_features_path:
        :param input_features_name:
        :param output_path:
        :return:
        """

        # Define ogr2ogr command
        # Added conversion between spatial references
        ogr_command = 'ogr2ogr -f "GML" \
                      -s_srs "urn:ogc:def:crs:EPSG::3081" \
                      -t_srs "urn:ogc:def:crs:EPSG::4269" \
                      -dsco FORMAT=GML3 -nln \
                      {0} {1} {2} -sql "SELECT GID \
                      AS RDBD_GMTRY_LN_ID, \
                      SEG_LEN AS RDBD_GMTRY_LN_MS, \
                      FID AS OBJECTID FROM \
                      {3}'.format('RoadbedGeometryLine', os.path.join(output_path, 'RoadbedGeometryLine.gml'),
                                  (input_features_path + os.sep + input_features_name),
                                  input_features_name.split(".")[0])

        # Create the ogr2ogr process
        logging.info("{0}".format(ogr_command))
        process = subprocess.Popen(ogr_command, stdout=subprocess.PIPE, creationflags=0x08000000)

        # Execute ogr2ogr process when available
        process.wait()

        logging.info("{0}...Writing RoadbedGeometryLine.gml"
                     .format(input_features_name.split("_")[0] + "_" + input_features_name.split("_")[1]))

        return True

    def create_etl_package(fc, output_folder):
        """
        Creates etl package for transmittal to GRID

        :param fc: input linework marked with ETL updates
        :param output_folder: location to output packets
        """
        where_clause = """ "EDIT_TYPE" IS NOT NULL AND "ETL_STAT" = 2 """

        arcpy.MakeFeatureLayer_management(fc, 'in_memory\\temp_fc', where_clause)

        job_list = {}
        job_rows = arcpy.SearchCursor('in_memory\\temp_fc')

        successful = 0
        failed = 0

        for job in job_rows:
            if job_limit is None or job.ETL_JOB_ID in job_limit:
                if job.ETL_JOB_ID not in job_list.keys():
                    job_list[job.ETL_JOB_ID] = [set(), set(), [], []]

                if job.EDIT_TYPE.startswith('Add'):
                    job_list[job.ETL_JOB_ID][2].append(job.GID)

                    if job.EDIT_TYPE == 'Add Route':
                        job_list[job.ETL_JOB_ID][0].add(job.RTE_GRID)

                elif job.EDIT_TYPE.startswith('Retire'):
                    job_list[job.ETL_JOB_ID][3].append(job.GID)

                    if job.EDIT_TYPE == 'Retire Route':
                        job_list[job.ETL_JOB_ID][1].add(job.RTE_GRID)		
						
        for job_process in job_list.keys():
            job_folder_path = os.path.join(output_folder, "ETL_Roadways-" + "job_" + str(job_process))
            temp_gdb_path = os.path.join(job_folder_path, 'temp.gdb')

            if not os.path.exists(job_folder_path):
                os.mkdir(job_folder_path)

            if not os.path.exists(temp_gdb_path):
                arcpy.CreateFileGDB_management(job_folder_path, "temp.gdb")

            env.workspace = temp_gdb_path

            job_query = "\"ETL_JOB_ID\" = \'{0}\'".format(job_process)
            job_id = "job_{0}".format(job_process)
            logging.info("{0} - Begin".format(job_id))

            arcpy.MakeFeatureLayer_management('in_memory\\temp_fc', job_id, job_query)

            # Check if GML is required
            add_cursor = arcpy.SearchCursor(job_id)
            terminal_coords = None

            for row in add_cursor:
                if str(row.EDIT_TYPE).split()[0] == 'Add':

                    add_query = """ "EDIT_TYPE" = 'Add Roadbed' OR "EDIT_TYPE" = 'Add Route' """

                    arcpy.MakeFeatureLayer_management(job_id, (job_id + "_adds"), add_query)

                    arcpy.FeatureClassToShapefile_conversion(job_id + '_adds', job_folder_path)

                    if create_gml(job_folder_path, job_id + "_adds.shp", job_folder_path):
                        gml_file = os.path.join(job_folder_path, 'RoadbedGeometryLine.gml')
                        terminal_coords = parse_gml_for_terminal_coords(gml_file)
                    break

            if create_xml(job_id, job_folder_path, job_list[job_process][0], job_list[job_process][1],
                          job_list[job_process][2], job_list[job_process][3], terminal_coords) is True:

                zip_etl_package(job_folder_path, cfg["paths"]["output_location"])

                successful += 1
                session_dictionary[str(job_id)] = {'job_type': 'Roadway', 'status': True}

                if debug is False:
                    arcpy.Delete_management(temp_gdb_path)
                    cleanup_directory(job_folder_path)

            else:
                failed += 1
                session_dictionary[str(job_id)] = {'job_type': 'Roadway', 'status': False}

            logging.info("{0} - End".format(job_id))
            logging.info("\n\n")

    features_path = cfg["paths"]["features"]
    create_etl_package(features_path, cfg["paths"]["output_location"])

    end_time = time.ctime()
    logging.info("Complete: " + end_time)
    end_date_time = datetime.datetime.now()
    run_time = (end_date_time - start_time_datetime)
    logging.info("Total Run Time: " + str(run_time))

    update_db_multiple(session_dictionary)

    if start_server:
        start_db()
    else:
        print "ETL Process Complete"
        
if __name__ == '__main__':
    '''
    Using argparse to allow arguments to be run from the command line with the application
    When the module is run it will verify the arguments for the jobs, debug, and weblog.
    If no arguments are passed, it will query the user for jobs to run.
    
    python basemap_test.py -j 552290 552292 -l CITY_DTL_POLY MPO_POLY -d
    '''
    parser = argparse.ArgumentParser()
    parser.add_argument('-j', '--job', action='store', nargs='+' , type=str, help='Space seperated list of integer job numbers')
    parser.add_argument('-d', '--debug', action='store_true')
    parser.add_argument('-w','--weblog', action='store_true')
    args = parser.parse_args()

    if args.job is None:
        job_args = raw_input('\nInsert job numbers seperated by commas (or All): ')
        if not job_args or job_args.lower() == 'all':
            args.job = None
        else:
            try:
                job_list = [str(x) for x in job_args.replace(" ", "").split(",")]
                args.job = job_list
            except ValueError:
                print('You did not enter a valid Job argument.  Please try again')
                sys.exit()

    etl(args.job,args.debug,args.weblog)
