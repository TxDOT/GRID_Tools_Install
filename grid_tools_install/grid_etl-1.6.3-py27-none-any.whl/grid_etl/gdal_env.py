import os
import subprocess
'''
This module will set the temporary PATH to GDAL from the installed GDAL python package.  Required to run OGR2OGR
Must be imported and run main() before another "import os" takes place (ie - loading etl_packet)
'''
#def main():
print("\nSetting Path to GDAL...")

def parent(p):
    return os.path.normpath(os.path.join(p, os.path.pardir))

rootDir = os.path.dirname(os.path.abspath(__file__))
gdalDir = os.path.join(parent(rootDir), 'osgeo')

os.environ["PATH"] = os.environ["PATH"] + ";" + gdalDir

gdalData = os.path.join(gdalDir, r'data\gdal')
gdalDriver = os.path.join(gdalDir, r'gdalplugins')
gdalInclude = os.path.join(gdalDir, r'include\gdal')
gdalLib = os.path.join(gdalDir, r'lib')

os.environ["GDAL_DATA"] = gdalData
os.environ["GDAL_DRIVER_PATH"] = gdalDriver
if os.environ.get("INCLUDE"):
    os.environ["INCLUDE"] = os.environ["INCLUDE"] + ";" + gdalInclude
else:
    os.environ["INCLUDE"] = gdalInclude
if os.environ.get("LIB"):
    os.environ["LIB"] = os.environ["LIB"] + ";" + gdalLib
else:
    os.environ["LIB"] = gdalLib
print("Completed\n")

#Test if Variable Set Properly
#subprocess.Popen('ogr2ogr --formats')
    
#if __name__ == "__main__":
#    main()