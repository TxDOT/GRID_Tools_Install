import gdal_env
import os
import time
import shutil
import logging
import argparse
import subprocess
import datetime
import arcpy
from arcpy import env
import yaml
from etl_config import config

def create_gml(java_name, output_file, fgdb_output, fgdb_layer):
    '''
        args:
            java_name = layer name that is used by the java functions
            output_file = actual gml file and path
            fgdb_output = actual geodatabase file and path
            fgdb_layer = layer name within gdb
        This method will run an ogr2ogr command for each job that is processed
        It will return the gml file to be uploaded to GRID, and an xsd file for validation
    '''
    ogr_command = 'ogr2ogr -overwrite -f "GML" -dsco FORMAT=GML3 '\
        '-s_srs "+proj=latlong +datum=NAD83 +axis=enu +wktext" '\
        '-t_srs "+proj=latlong +datum=NAD83 +axis=neu +wktext" '\
        '-nln {0} {1} {2} '\
        '-sql "SELECT * FROM {3}" '.format(java_name,output_file, fgdb_output, fgdb_layer)
    process = subprocess.Popen(ogr_command, stdout=subprocess.PIPE, creationflags=0x08000000)
    process.wait()

    logging.info("FILE CREATED: {0}".format(output_file))
    logging.info("OGR_COMMAND: {0}\n".format(ogr_command))

def cleanup_directory(fgdb_output):
    '''
        args:
            fgdb_output = fgdb file and path
        This method will remove the geodatabase created for the processing of each job
        It is only run when debug mode is set to true
    '''
    for xsd_file in os.listdir(os.path.dirname(fgdb_output)):
        if xsd_file.endswith(".xsd"):
            os.remove(os.path.join(os.path.dirname(fgdb_output), xsd_file))
    shutil.rmtree(fgdb_output)

def create_basemap_etl(output_path, job_limit, layer_limit, debug):
    '''
        args:
            output_path = main output directory for all subfolders and files
            job_limit = list of integer job numbers [123, 456, 789]
            layer_limit = list of string layer names ['CITY_DTL_PLY', 'MPO_POLY']
            debug = Keep gdb and xsd output files for debug purposes
        This method will handle the main logic to determe which job packets are created.
        It will handle calls to create gml objects and clear out temporary files.
    '''
    session_dictionary = {}
    name_dictionary = {
        'ADJ_STATE_POLY': 'AdjoiningStatePoly',
        'AIRPORT_PNT': 'AirportPoint',
        'AIRPORT_POLY': 'AirportBoundaryPoly',
        'AIRPORT_RUNWAYS_POLY': 'AirportRunwayPoly',
        'CEMETERY_PNT': 'CemeteryPoint',
        'CEMETERY_POLY': 'CemeteryBoundaryPoly',
        'CITY_DTL_POLY': 'CityDetailPoly',
        'CITY_PNT': 'CityPoint',
        'EDUCATION_POLY': 'EducationBoundaryPoly',
        'GRID_BUFFER': 'GridBuffer',
        'LAKE_POLY': 'LakePoly',
        'MILIT_LAND_POLY': 'MilitaryLandBoundaryPoly',
        'MPO_POLY': 'MpoBoundaryPoly',
        'MSA_POLY': 'MsaBoundaryPoly',
        'PBLC_LAND_POLY': 'PublicLandPoly',
        'PRISON_POLY': 'PrisonBoundaryPoly',
        'RAIL_RD_LN': 'RailroadLine',
        'STRM_DTL_LN': 'StreamDetailLine',
        'TXDOT_CNTY_LN': 'TxdotCountyBoundaryLine',
        'TXDOT_CNTY_POLY': 'TxdotCountyBoundaryPoly',
        'TXDOT_CNTY_DETAIL_POLY': 'TxdotCountyDetailBoundaryPoly',
        'TXDOT_DIST_LN': 'TxdotDistrictBoundaryLine',
        'TXDOT_DIST_POLY': 'TxdotDistrictBoundaryPoly',
        'TXDOT_OFFICE_MAINT_POLY': 'TxdotMaintSectionPoly',
        'TXDOT_REGN_POLY': 'TxdotRegionBoundaryPoly',
        'UZA_POLY': 'UrbanAreaPoly'
    }

    for lyr in arcpy.ListFeatureClasses():
        lyr_name = lyr.split(".")[-1]
        
        if lyr_name not in name_dictionary:
            logging.info('Layer {0} is not in the Layer Dictionary\n'.format(lyr_name))
            continue
        if layer_limit and lyr_name not in layer_limit:
            continue
            
        mem_lyr = 'in_memory\\' + lyr + '_changes'
        arcpy.MakeFeatureLayer_management(lyr, mem_lyr, """ "GRID_OP" = 'Add' OR "GRID_OP" = 'Replace' OR "GRID_OP" = 'Delete'""")
        count = int(arcpy.GetCount_management(mem_lyr).getOutput(0))

        logging.info('Basemap - {0}; {1} feature edits found\n'.format(lyr_name, count))

        if not count:
            continue
        
        jobs_list = []
        java_name = name_dictionary[lyr_name]
        
        for row in arcpy.SearchCursor(mem_lyr):
            if row.ETL_TEST_ID not in jobs_list:
                jobs_list.append(row.ETL_TEST_ID)
            
        for job in jobs_list:
            if job_limit and job not in job_limit:
                continue
            
            job_path = os.path.join(output_path, 'etl_basemap-job_' + str(job))
            if not os.path.exists(job_path):
                os.mkdir(job_path)
            
            fgdb_name = 'etl_basemap_' + 'job' + str(job) + '.gdb'
            fgdb_output = os.path.join(job_path, fgdb_name)
            fgdb_layer = lyr_name + '_changes_job' + str(job)
            
            if not os.path.exists(fgdb_output):
                arcpy.CreateFileGDB_management(job_path, fgdb_name, "CURRENT")
            arcpy.FeatureClassToFeatureClass_conversion(mem_lyr, fgdb_output, fgdb_layer, """ "ETL_TEST_ID" = {0}""".format(job))
            
            output_file = os.path.join(job_path, java_name + '-job{0}.gml'.format(job))
            if os.path.exists(output_file):
                os.remove(output_file)
            
            create_gml(java_name, output_file, fgdb_output, fgdb_layer)
            
            # Edit made to add basement job report to ETL page
            session_dictionary[str(job)] = {'job_type': 'Roadway', 'status': True}
            
            if debug is False and fgdb_output is not None:
                cleanup_directory(fgdb_output)

def etl(job_limit=None, layer_limit=None, debug=False):
    '''
        args:
            job_limit = list of integer job numbers ie [123, 456, 789]
            layer_limit = list of string layer names ie ['CITY_DTL_PLY', 'MPO_POLY']
            debug = Keep gdb and xsd output files for debug purposes; True will keep, False will remove
        This is the main method for the basemap etl package.  It will handle logging set-up, high level
        path creation, reading the configuration file, and calls to the working methods.
        
        from grid_etl import etl_basemap
        etl_basemap.etl([552290, 552292], ['CITY_DTL_POLY','MPO_POLY'], True )
    '''

    print(job_limit, layer_limit)
    start_time = datetime.datetime.now()
    
    current_directory = os.path.dirname(os.path.realpath(__file__))
    config_file = os.path.join(current_directory, 'etl_config_resources\\etl_config_paths.yml')
    if not os.path.exists(config_file):
        config()
        print "\nContinuing with grid_etl."
    # Open and read configuration file
    with open(config_file, 'r') as ymlfile:
        cfg = yaml.load(ymlfile)

    log_directory = os.path.join(cfg["paths"]["output_location"], 'basemap_log')
    basemap_path = cfg["paths"]["basemap_geodatabase"]
    output_path = cfg["paths"]["output_location"] 

    #Create logging path and file; begin logging for the application
    if not os.path.exists(log_directory):
        os.makedirs(log_directory)
    log_file = os.path.join(log_directory, time.strftime("%m.%d.%Y_%H.%M") + "_log.txt")
    logging.basicConfig(filename=log_file,
                        level=logging.DEBUG,
                        filemode='w',
                        format='%(asctime)s - %(levelname)s: %(message)s',
                        datefmt='%m/%d/%Y %H:%M:%S ')

    logging.info("Begin Basemap ETL Process")
    logging.info("Configuration file loaded...")
    logging.info("Basemap Location: " + basemap_path)
    logging.info("Output Location: " + output_path + "\n")
    
    #set arcpy workspace environment  to query the basemap features from config file
    env.workspace = basemap_path
    env.overwriteOutput = True
    
    create_basemap_etl(output_path, job_limit, layer_limit, debug)

    logging.info("Completed Basemap ETL Process Successfully")
    end_time = datetime.datetime.now()
    run_time = (end_time - start_time)
    logging.info("Total Run Time: " + str(run_time))
    
if __name__ == '__main__':
    '''
    Using argparse to allow arguments to be run from the command line with the application
    When the module is run it will verify the arguments for jobs, layers and debug.
    If no arguments are passed, it will query the user for jobs and layers to run.
    
    python basemap_test.py -j 552290 552292 -l CITY_DTL_POLY MPO_POLY -d
    '''
    parser = argparse.ArgumentParser()
    parser.add_argument('-j', '--job', action='store', nargs='+' , type=int, help='Space seperated list of integer job numbers')
    parser.add_argument('-l', '--layer', action='store',  nargs='+', type=str, help = 'Space seperated list of basemap layers')
    parser.add_argument('-d', '--debug', action='store_true')
    args = parser.parse_args()

    if args.job is None:
        job_args = raw_input('\nInsert job numbers seperated by commas (or All): ')
        if not job_args or job_args.lower() == 'all':
            args.job = None
        else:
            try:
                job_list = [int(x) for x in job_args.replace(" ", "").split(",")]
                args.job = job_list
            except ValueError:
                print('You did not enter a valid Job argument.  Please try again')
                sys.exit()
    
    if args.layer is None:
        layer_args = raw_input('\nInsert basemap layer names seperated by commas (or All): ')
        if not layer_args or layer_args.lower() == 'all':
            args.layer = None
        else:
            layer_list = layer_args.replace(" ", "").split(",")
            args.layer = layer_list
    elif ''.join(map(str.lower, args.layer)) == 'all':
        args.layer = None
        
    etl(args.job,args.layer,args.debug)