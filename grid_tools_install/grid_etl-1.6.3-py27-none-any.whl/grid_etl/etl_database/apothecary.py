__author__ = 'DHICKMA'
"""
The MIT License (MIT)

Copyright (c) 2014 Texas Department of Transportation

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

"""

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from os import path
from datetime import datetime

from potions import Base, Packets

current_directory = path.dirname(path.realpath(__file__))
db_file = path.join(current_directory, 'etl_packets.db')
connect_string = 'sqlite:///{0}'.format(db_file.encode('string-escape'))


def set_engine():
    engine = create_engine(connect_string)
    return engine


def create_session():
    Engine = set_engine()
    Session = sessionmaker(bind=Engine)
    session = Session()
    return session


def create_tables():
    Engine = set_engine()
    Base.metadata.create_all(Engine)


def update_db_multiple(packet_dictionary):
    session = create_session()
    for k, v in packet_dictionary.iteritems():
        processed_packets = [str(p[0]) for p in session.query(Packets.job).all()]
        if k not in processed_packets:
            p = Packets(job=k, job_type=v['job_type'], status=v['status'])
            session.add(p)
        else:
            p = session.query(Packets).filter_by(job=k).first()
            p.job_type = v['job_type']
            p.status = v['status']
            p.last_update = datetime.now()
    session.commit()
    session.close()
