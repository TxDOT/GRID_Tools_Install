import os
import csv

asset_pnt = ['BaselineBearing', 'BaselineBearingComponent', 'CattleGuard', 'Cemetery', 'Crossover', 'Culvert', 'Driveway', 'FirePlug', 'Gate',
    'HistoricalMarker', 'LitterBarrel', 'MaterialStockpile', 'OtherIntersectFeature', 'OverheadSign', 'PedestrianPassageway', 'PicnicArea', 'PipelineCrossing',
    'RailroadCrossing', 'RestArea', 'RoadbedIntersection', 'ScenicOverlook', 'StreamCrossing', 'TelephoneLine', 'TestSite', 'TollBooth', 'TouristInformationCenter',
    'TrafficManagementInstrument', 'TrafficMonitorSite', 'TransmissionLine', 'TxdotFacility', 'Utility', 'WaterlineCrossing']
    
# For Select Query , add in LEFT JOIN GRIDOP.RTE_DEFN_LN ON RTE_DEFN_LN.RDBD_GMTRY_LN_ID = ASSET.RDBD_GMTRY_LN_ID 
#This will allow us to add search parameters (get RAW_INPUT for a WHERE CLAUSE) based on Route Name, Number, Classification, etc (leave it open-ended, but restricted)

def create_table(asset):
    base_query = '''
        CREATE TABLE IF NOT EXISTS {0} (
            YEAR_RECORD INTEGER,
            STATE_CODE INTEGER,
            ROUTE_ID INTEGER,
            BEGIN_POINT NUMERIC(7,3),
            END_POINT NUMERIC(7,3),
            SECTION_LENGTH NUMERIC(7,3),
            COMMENTS VARCHAR(100),
            RECORD_ID INTEGER,
            ASSET_STAT_INDCTR VARCHAR(10),
            ASSET_EDIT_USER_NM VARCHAR(50),
            ASSET_GMTRY_TYPE_NM VARCHAR(50),
            ASSET_EFF_END_DT DATE,
            ASSET_CREATE_USER_NM VARCHAR(50),
            ASSET_RDBD_GMTRY_LN_ID INTEGER,
            ASSET_RDBD_TYPE_ID INTEGER,
            ASSET_EFF_START_DT DATE,
            ASSET_CREATE_DT DATE,
            ASSET_EDIT_DT DATE,
            {1}
            GRIDOP VARCHAR(10)
        )
    '''
    if asset == 'AlternateRoute':
        asset_query = '''
            Alternative_Route_Name VARCHAR(50),
            ALT_RTE_OFCL_NM_FLAG VARCHAR(1),
        '''
    elif asset == 'Bridge':
        asset_query = '''
            BRDG_STRUC_NBR VARCHAR(15),
            BRDG_NM VARCHAR(50),
            BRDG_DSCR VARCHAR(255),
        '''
    elif asset == 'CattleGuard':
        asset_query = '''
            CATTL_GRD_CRS_FEAT_GRADE_ID INTEGER,
            CATTL_GRD_FEAT_GRADE_TYPE_ID INTEGER,
            CATTL_GRD_INTSECT_ALGN_TYPE_ID INTEGER,
            CATTL_GRD_CRS_ANGL INTEGER,
            CATTL_GRD_INTSECT_TYPE_ID INTEGER,
            CATTL_GRD_BRDG_ID INTEGER,
        '''
    elif asset == 'FunctionalSystem':
        asset_query = '''
            F_System INTEGER,
        '''

    sql = base_query.format(asset, asset_query)
    print(sql)
    return sql
    
def select_table(asset):
    if asset in asset_pnt:
        base_query = '''
            SELECT '2015'                                                                 AS YEAR_RECORD,
                '48'                                                                        AS STATE_CODE,
                GRIDOP.ASSET.RDBD_GMTRY_LN_ID                                               AS ROUTE_ID,
                TO_CHAR(GRIDOP.ASSET_PNT.ASSET_PNT_DFO_MS)                                       AS BEGIN_POINT,
                NULL                                                                                            AS END_POINT,
                0                                                                                                    AS SECTION_LENGTH,
                GRIDOP.ASSET.ASSET_CMNT                                                     AS COMMENTS,
                GRIDOP.ASSET.ASSET_ID                                                       AS RECORD_ID,
                GRIDOP.ASSET.STAT_INDCTR                                                    AS ASSET_STAT_INDCTR,
                GRIDOP.ASSET.ASSET_EDIT_USER_NM                                             AS ASSET_EDIT_USER_NM,
                GRIDOP.ASSET.GMTRY_TYPE_NM                                                  AS ASSET_GMTRY_TYPE_NM,
                TO_CHAR(GRIDOP.ASSET.ASSET_EFF_END_DT, 'YYYY-MM-DD')                                               AS ASSET_EFF_END_DT,
                GRIDOP.ASSET.ASSET_CREATE_USER_NM                                           AS ASSET_CREATE_USER_NM,
                GRIDOP.ASSET.RDBD_GMTRY_LN_ID                                               AS ASSET_RDBD_GMTRY_LN_ID,
                GRIDOP.ASSET.RDBD_TYPE_ID                                                   AS ASSET_RDBD_TYPE_ID,
                TO_CHAR(GRIDOP.ASSET.ASSET_EFF_START_DT, 'YYYY-MM-DD')                                             AS ASSET_EFF_START_DT,
                TO_CHAR(GRIDOP.ASSET.ASSET_CREATE_DT, 'YYYY-MM-DD')                                                AS ASSET_CREATE_DT,
                TO_CHAR(GRIDOP.ASSET.ASSET_EDIT_DT, 'YYYY-MM-DD')                                                  AS ASSET_EDIT_DT,
                {0}
                NULL                                                                                            AS GRIDOP
            FROM {1} tbl
            LEFT JOIN GRIDOP.ASSET_PNT
            ON GRIDOP.ASSET_PNT.ASSET_ID = tbl.ASSET_ID
            LEFT JOIN GRIDOP.ASSET
            ON GRIDOP.ASSET.ASSET_ID = GRIDOP.ASSET_PNT.ASSET_ID
            ORDER BY ROUTE_ID
        '''
        if asset == 'CattleGuard':
            asset_table = 'GRIDOP.CATTL_GRD'
            asset_query = '''
                tbl.CRS_FEAT_GRADE_ID                         AS CATTL_GRD_CRS_FEAT_GRADE_ID,
                tbl.FEAT_GRADE_TYPE_ID                        AS CATTL_GRD_FEAT_GRADE_TYPE_ID,
                tbl.INTSECT_ALGN_TYPE_ID                      AS CATTL_GRD_INTSECT_ALGN_TYPE_ID,
                tbl.CRS_ANGL                                              AS CATTL_GRD_CRS_ANGL,
                tbl.INTSECT_TYPE_ID                               AS CATTL_GRD_INTSECT_TYPE_ID,
                tbl.BRDG_ID                                               AS CATTL_GRD_BRDG_ID,
            '''

    elif asset not in asset_pnt:
        base_query = '''
            SELECT '2015'                                                                 AS YEAR_RECORD,
                '48'                                                                        AS STATE_CODE,
                GRIDOP.ASSET.RDBD_GMTRY_LN_ID                                               AS ROUTE_ID,
                TO_CHAR(GRIDOP.ASSET_LN.ASSET_LN_BEGIN_DFO_MS)                                       AS BEGIN_POINT,
                TO_CHAR(GRIDOP.ASSET_LN.ASSET_LN_END_DFO_MS)                                         AS END_POINT,
                TO_CHAR(GRIDOP.ASSET_LN.ASSET_LN_END_DFO_MS - GRIDOP.ASSET_LN.ASSET_LN_BEGIN_DFO_MS) AS SECTION_LENGTH,
                GRIDOP.ASSET.ASSET_CMNT                                                     AS COMMENTS,
                GRIDOP.ASSET.ASSET_ID                                                       AS RECORD_ID,
                GRIDOP.ASSET.STAT_INDCTR                                                    AS ASSET_STAT_INDCTR,
                GRIDOP.ASSET.ASSET_EDIT_USER_NM                                             AS ASSET_EDIT_USER_NM,
                GRIDOP.ASSET.GMTRY_TYPE_NM                                                  AS ASSET_GMTRY_TYPE_NM,
                TO_CHAR(GRIDOP.ASSET.ASSET_EFF_END_DT, 'YYYY-MM-DD')                                               AS ASSET_EFF_END_DT,
                GRIDOP.ASSET.ASSET_CREATE_USER_NM                                           AS ASSET_CREATE_USER_NM,
                GRIDOP.ASSET.RDBD_GMTRY_LN_ID                                               AS ASSET_RDBD_GMTRY_LN_ID,
                GRIDOP.ASSET.RDBD_TYPE_ID                                                   AS ASSET_RDBD_TYPE_ID,
                TO_CHAR(GRIDOP.ASSET.ASSET_EFF_START_DT, 'YYYY-MM-DD')                                             AS ASSET_EFF_START_DT,
                TO_CHAR(GRIDOP.ASSET.ASSET_CREATE_DT, 'YYYY-MM-DD')                                                AS ASSET_CREATE_DT,
                TO_CHAR(GRIDOP.ASSET.ASSET_EDIT_DT, 'YYYY-MM-DD')                                                  AS ASSET_EDIT_DT,
                {0}
                NULL                                                                                            AS GRIDOP
            FROM {1} tbl
            LEFT JOIN GRIDOP.ASSET_LN
            ON GRIDOP.ASSET_LN.ASSET_ID = tbl.ASSET_ID
            LEFT JOIN GRIDOP.ASSET
            ON GRIDOP.ASSET.ASSET_ID = GRIDOP.ASSET_LN.ASSET_ID
            ORDER BY ROUTE_ID
        '''
        if asset == 'AlternateRoute':
            asset_table = 'GRIDOP.ALT_RTE'
            asset_query = '''
                tbl.ALT_RTE_NM                                                   AS Alternative_Route_Name,
                tbl.ALT_RTE_OFCL_NM_FLAG                                         AS ALT_RTE_OFCL_NM_FLAG,
            '''
        elif asset == 'Bridge':
            asset_table = 'GRIDOP.BRDG'
            asset_query = '''
                tbl.BRDG_STRUC_NBR                                                  AS BRDG_STRUC_NBR,
                tbl.BRDG_NM                                                         AS BRDG_NM,
                tbl.BRDG_DSCR                                                       AS BRDG_DSCR,
            '''
        elif asset == 'FunctionalSystem':
            asset_table = 'GRIDOP.FUNCL_SYS'
            asset_query = '''
                tbl.FUNCL_SYS_TYPE_ID                                               AS F_System,
            '''

    sql = base_query.format(asset_query,asset_table)
    print(sql)
    return sql
    
def insert_table(asset):
    base_query = '''
        INSERT INTO {0} VALUES({1})
     '''
     
    if asset == 'AlternateRoute':
        asset_query = '?,' * 20 + '?'
    elif asset == 'Bridge':
        asset_query = '?,' * 21 + '?'
    elif asset == 'CattleGuard':
        asset_query = '?,' * 24 + '?'
    elif asset == 'FunctionalSystem':
        asset_query = '?,' * 19 + '?'
        
    sql = base_query.format(asset, asset_query)
    print(sql)
    return sql
    
def unpivot_table(asset):
    base_query = '''
        WITH t1 AS
            (SELECT * FROM {0})
        SELECT t2.*
        FROM
            (
            SELECT YEAR_RECORD, STATE_CODE, ROUTE_ID, BEGIN_POINT,  END_POINT, SECTION_LENGTH, 'ASSET_STAT_INDCTR' AS DATA_ITEM, NULL AS VALUE_NUMERIC, ASSET_STAT_INDCTR AS VALUE_TEXT, NULL AS VALUE_DATE, COMMENTS, RECORD_ID, GRIDOP FROM t1
            UNION ALL
            SELECT YEAR_RECORD, STATE_CODE, ROUTE_ID, BEGIN_POINT, END_POINT, SECTION_LENGTH, 'ASSET_EDIT_USER_NM' AS DATA_ITEM, NULL AS VALUE_NUMERIC, ASSET_EDIT_USER_NM AS VALUE_TEXT, NULL AS VALUE_DATE, COMMENTS, RECORD_ID, GRIDOP FROM t1
            UNION ALL
            SELECT YEAR_RECORD, STATE_CODE, ROUTE_ID, BEGIN_POINT, END_POINT, SECTION_LENGTH, 'ASSET_GMTRY_TYPE_NM' AS DATA_ITEM, NULL AS VALUE_NUMERIC, ASSET_GMTRY_TYPE_NM AS VALUE_TEXT, NULL AS VALUE_DATE, COMMENTS, RECORD_ID, GRIDOP FROM t1
            UNION ALL
            SELECT YEAR_RECORD, STATE_CODE, ROUTE_ID, BEGIN_POINT, END_POINT, SECTION_LENGTH, 'ASSET_EFF_END_DT' AS DATA_ITEM, NULL AS VALUE_NUMERIC, NULL AS VALUE_TEXT, ASSET_EFF_END_DT AS VALUE_DATE, COMMENTS, RECORD_ID, GRIDOP FROM t1
            UNION ALL
            SELECT YEAR_RECORD, STATE_CODE, ROUTE_ID, BEGIN_POINT, END_POINT, SECTION_LENGTH, 'ASSET_CREATE_USER_NM' AS DATA_ITEM, NULL AS VALUE_NUMERIC, ASSET_CREATE_USER_NM AS VALUE_TEXT, NULL AS VALUE_DATE, COMMENTS, RECORD_ID, GRIDOP FROM t1    
            UNION ALL
            SELECT YEAR_RECORD, STATE_CODE, ROUTE_ID, BEGIN_POINT, END_POINT, SECTION_LENGTH, 'ASSET_RDBD_GMTRY_LN_ID' AS DATA_ITEM, ASSET_RDBD_GMTRY_LN_ID AS VALUE_NUMERIC, NULL AS VALUE_TEXT, NULL AS VALUE_DATE, COMMENTS, RECORD_ID, GRIDOP FROM t1    
            UNION ALL
            SELECT YEAR_RECORD, STATE_CODE, ROUTE_ID, BEGIN_POINT, END_POINT, SECTION_LENGTH, 'ASSET_RDBD_TYPE_ID' AS DATA_ITEM, ASSET_RDBD_TYPE_ID AS VALUE_NUMERIC, NULL AS VALUE_TEXT, NULL AS VALUE_DATE, COMMENTS, RECORD_ID, GRIDOP FROM t1    
            UNION ALL
            SELECT YEAR_RECORD, STATE_CODE, ROUTE_ID, BEGIN_POINT, END_POINT, SECTION_LENGTH, 'ASSET_EFF_START_DT' AS DATA_ITEM, NULL AS VALUE_NUMERIC, NULL AS VALUE_TEXT, ASSET_EFF_START_DT AS VALUE_DATE, COMMENTS, RECORD_ID, GRIDOP FROM t1    
            UNION ALL
            SELECT YEAR_RECORD, STATE_CODE, ROUTE_ID, BEGIN_POINT, END_POINT, SECTION_LENGTH, 'ASSET_CREATE_DT' AS DATA_ITEM, NULL AS VALUE_NUMERIC, NULL AS VALUE_TEXT, ASSET_CREATE_DT AS VALUE_DATE, COMMENTS, RECORD_ID, GRIDOP FROM t1    
            UNION ALL
            SELECT YEAR_RECORD, STATE_CODE, ROUTE_ID, BEGIN_POINT, END_POINT, SECTION_LENGTH, 'ASSET_EDIT_DT' AS DATA_ITEM, NULL AS VALUE_NUMERIC, NULL AS VALUE_TEXT, ASSET_EDIT_DT AS VALUE_DATE, COMMENTS, RECORD_ID, GRIDOP FROM t1    
            UNION ALL
            {1}
            ) t2
        ORDER BY RECORD_ID,
            CASE
            WHEN DATA_ITEM = 'ASSET_STAT_INDCTR' THEN 'a'
            WHEN DATA_ITEM = 'ASSET_EDIT_USER_NM' THEN 'b'
            WHEN DATA_ITEM = 'ASSET_GMTRY_TYPE_NM' THEN 'c'
            WHEN DATA_ITEM = 'ASSET_EFF_END_DT' THEN 'd'
            WHEN DATA_ITEM = 'ASSET_CREATE_USER_NM' THEN 'e'
            WHEN DATA_ITEM = 'ASSET_RDBD_GMTRY_LN_ID' THEN 'f'
            WHEN DATA_ITEM = 'ASSET_RDBD_TYPE_ID' THEN 'g'
            WHEN DATA_ITEM = 'ASSET_EFF_START_DT' THEN 'h'
            WHEN DATA_ITEM = 'ASSET_CREATE_DT' THEN 'i'
            WHEN DATA_ITEM = 'ASSET_EDIT_DT' THEN 'j'
            {2}
            ELSE DATA_ITEM
            END
        ASC
    '''
    if asset == 'AlternateRoute':
        asset_query = '''
            SELECT YEAR_RECORD, STATE_CODE, ROUTE_ID, BEGIN_POINT, END_POINT, SECTION_LENGTH, 'Alternative_Route_Name' AS DATA_ITEM, NULL AS VALUE_NUMERIC, Alternative_Route_Name AS VALUE_TEXT, NULL AS VALUE_DATE, COMMENTS, RECORD_ID, GRIDOP FROM t1    
            UNION ALL
            SELECT YEAR_RECORD, STATE_CODE, ROUTE_ID, BEGIN_POINT, END_POINT, SECTION_LENGTH, 'ALT_RTE_OFCL_NM_FLAG' AS DATA_ITEM, NULL AS VALUE_NUMERIC, ALT_RTE_OFCL_NM_FLAG AS VALUE_TEXT, NULL AS VALUE_DATE, COMMENTS, RECORD_ID, GRIDOP FROM t1    
        '''
        asset_order = '''
            WHEN DATA_ITEM = 'Alternative_Route_Name' THEN 'k'
            WHEN DATA_ITEM = 'ALT_RTE_OFCL_NM_FLAG' THEN 'l'
        '''
    elif asset == 'Bridge':
        asset_query = '''
            SELECT YEAR_RECORD, STATE_CODE, ROUTE_ID, BEGIN_POINT, END_POINT, SECTION_LENGTH, 'BRDG_STRUC_NBR' AS DATA_ITEM, NULL AS VALUE_NUMERIC, BRDG_STRUC_NBR AS VALUE_TEXT, NULL AS VALUE_DATE, COMMENTS, RECORD_ID, GRIDOP FROM t1    
            UNION ALL
            SELECT YEAR_RECORD, STATE_CODE, ROUTE_ID, BEGIN_POINT, END_POINT, SECTION_LENGTH, 'BRDG_NM' AS DATA_ITEM, NULL AS VALUE_NUMERIC, BRDG_NM AS VALUE_TEXT, NULL AS VALUE_DATE, COMMENTS, RECORD_ID, GRIDOP FROM t1    
            UNION ALL
            SELECT YEAR_RECORD, STATE_CODE, ROUTE_ID, BEGIN_POINT, END_POINT, SECTION_LENGTH, 'BRDG_DSCR' AS DATA_ITEM, NULL AS VALUE_NUMERIC, BRDG_DSCR AS VALUE_TEXT, NULL AS VALUE_DATE, COMMENTS, RECORD_ID, GRIDOP FROM t1  
        '''
        asset_order = '''
            WHEN DATA_ITEM = 'BRDG_STRUC_NBR' THEN 'k'
            WHEN DATA_ITEM = 'BRDG_NM' THEN 'l'
            WHEN DATA_ITEM = 'BRDG_DSCR' THEN 'm'
        '''
    elif asset == 'CattleGuard':
        asset_query = '''
            SELECT YEAR_RECORD, STATE_CODE, ROUTE_ID, BEGIN_POINT, END_POINT, SECTION_LENGTH, 'CATTL_GRD_CRS_FEAT_GRADE_ID' AS DATA_ITEM, CATTL_GRD_CRS_FEAT_GRADE_ID AS VALUE_NUMERIC, NULL AS VALUE_TEXT, NULL AS VALUE_DATE, COMMENTS, RECORD_ID, GRIDOP FROM t1    
            UNION ALL
            SELECT YEAR_RECORD, STATE_CODE, ROUTE_ID, BEGIN_POINT, END_POINT, SECTION_LENGTH, 'CATTL_GRD_FEAT_GRADE_TYPE_ID' AS DATA_ITEM, CATTL_GRD_FEAT_GRADE_TYPE_ID AS VALUE_NUMERIC, NULL AS VALUE_TEXT, NULL AS VALUE_DATE, COMMENTS, RECORD_ID, GRIDOP FROM t1    
            UNION ALL
            SELECT YEAR_RECORD, STATE_CODE, ROUTE_ID, BEGIN_POINT, END_POINT, SECTION_LENGTH, 'CATTL_GRD_INTSECT_ALGN_TYPE_ID' AS DATA_ITEM, CATTL_GRD_INTSECT_ALGN_TYPE_ID AS VALUE_NUMERIC, NULL AS VALUE_TEXT, NULL AS VALUE_DATE, COMMENTS, RECORD_ID, GRIDOP FROM t1  
            UNION ALL
            SELECT YEAR_RECORD, STATE_CODE, ROUTE_ID, BEGIN_POINT, END_POINT, SECTION_LENGTH, 'CATTL_GRD_CRS_ANGL' AS DATA_ITEM, CATTL_GRD_CRS_ANGL AS VALUE_NUMERIC, NULL AS VALUE_TEXT, NULL AS VALUE_DATE, COMMENTS, RECORD_ID, GRIDOP FROM t1    
            UNION ALL
            SELECT YEAR_RECORD, STATE_CODE, ROUTE_ID, BEGIN_POINT, END_POINT, SECTION_LENGTH, 'CATTL_GRD_INTSECT_TYPE_ID' AS DATA_ITEM, CATTL_GRD_INTSECT_TYPE_ID AS VALUE_NUMERIC, NULL AS VALUE_TEXT, NULL AS VALUE_DATE, COMMENTS, RECORD_ID, GRIDOP FROM t1    
            UNION ALL
            SELECT YEAR_RECORD, STATE_CODE, ROUTE_ID, BEGIN_POINT, END_POINT, SECTION_LENGTH, 'CATTL_GRD_BRDG_ID' AS DATA_ITEM, CATTL_GRD_BRDG_ID AS VALUE_NUMERIC, NULL AS VALUE_TEXT, NULL AS VALUE_DATE, COMMENTS, RECORD_ID, GRIDOP FROM t1  
        '''
        asset_order = '''
            WHEN DATA_ITEM = 'CATTL_GRD_CRS_FEAT_GRADE_ID' THEN 'k'
            WHEN DATA_ITEM = 'CATTL_GRD_FEAT_GRADE_TYPE_ID' THEN 'l'
            WHEN DATA_ITEM = 'CATTL_GRD_INTSECT_ALGN_TYPE_ID' THEN 'm'
            WHEN DATA_ITEM = 'CATTL_GRD_CRS_ANGL' THEN 'n'
            WHEN DATA_ITEM = 'CATTL_GRD_INTSECT_TYPE_ID' THEN 'o'
            WHEN DATA_ITEM = 'CATTL_GRD_BRDG_ID' THEN 'p'
        '''
    elif asset == 'FunctionalSystem':
        asset_query = '''
            SELECT YEAR_RECORD, STATE_CODE, ROUTE_ID, BEGIN_POINT, END_POINT, SECTION_LENGTH, 'F_System' AS DATA_ITEM, F_System AS VALUE_NUMERIC, NULL AS VALUE_TEXT, NULL AS VALUE_DATE, COMMENTS, RECORD_ID, GRIDOP FROM t1    
        '''
        asset_order = '''
            WHEN DATA_ITEM = 'F_System' THEN 'k'
        '''
    
    sql = base_query.format(asset, asset_query, asset_order)
    print(sql)
    return sql
