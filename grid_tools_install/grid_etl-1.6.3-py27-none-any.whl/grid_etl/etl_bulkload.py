import os
import sys, argparse
import csv
import cx_Oracle
import sqlite3
import connections
from etl_bulkload_queries import create_table, select_table, insert_table, unpivot_table

def grid_export(o_con, asset, filePath):
    print('Here We Will Export the Query of choice')
    sql =select_table(asset)
    cursed = o_con.cursor()
    rows = cursed.execute(sql)
    #for row in rows:
        #print(row)
    with open(filePath + '\\' + asset +'.csv', 'wb') as f:
        writer = csv.writer(f, delimiter='|')
        writer.writerow([i[0] for i in cursed.description])
        writer.writerows(rows)
    print('Using ' + str(o_con) + '\nExtracted ' + asset + '\nTo directory ' + filePath)
    
def sqlite_import(s_con, asset, filePath):
    print('Here we will take the csv file and insert it into sqlite database :)')
    sqlCreate = create_table(asset)
    sqlInsert = insert_table(asset)
    cursed = s_con.cursor()
    cursed.execute(sqlCreate)
    
    with open(filePath + '\\' + asset +'.csv', 'rb') as f:
        reader = csv.reader(f, delimiter='|')
        i = 0
        for row in reader:
            cursed.execute(sqlInsert, row)
            
    s_con.commit()
    
    print('Using ' + str(s_con) + '\nInserted ' + asset + '\nToDirectory ' + filePath)
    
def create_packet(s_con, asset, filePath):
    print('Here we will create the actual bulkLoad packet for import to GRID')
    sqlUnpivot = unpivot_table(asset)
    cursed = s_con.cursor()
    rows = cursed.execute(sqlUnpivot)
    
    with open(filePath + '\\' + asset +'_final.csv', 'wb') as f:
        writer = csv.writer(f, delimiter='|')
        writer.writerow([i[0] for i in cursed.description])
        writer.writerows(rows)

def main(filePath, db_env):
    asset = raw_input('Please Enter the Asset you wish to extract (will create GUI with dropdown later): ')
    o_con = connections.grid_con(db_env)
    s_con = connections.sqlite_con(filePath + r'\BulkLoad.sqlite')
    grid_export(o_con, asset, filePath)
    sqlite_import(s_con, asset, filePath)
    create_packet(s_con, asset, filePath)
    
if __name__ == '__main__':
    main(r'C:\_ETL\BulkLoadTest' ,'prod')