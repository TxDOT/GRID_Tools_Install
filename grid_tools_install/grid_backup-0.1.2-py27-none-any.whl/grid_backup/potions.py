#  The MIT License (MIT)
#
#  Copyright (c) 2015 Texas Department of Transportation
#  Author: David Hickman
#
#  Permission is hereby granted, free of charge, to any person obtaining a copy
#  of this software and associated documentation files (the "Software"), to deal
#  in the Software without restriction, including without limitation the rights
#  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#  copies of the Software, and to permit persons to whom the Software is
#  furnished to do so, subject to the following conditions:
#
#  The above copyright notice and this permission notice shall be included in
#  all copies or substantial portions of the Software.
#
#  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
#  THE SOFTWARE.


from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy import Column, Integer, String, Float, Date, ForeignKey

Base = declarative_base()


# Domain Table Definitions
class AssetLnType(Base):
    __tablename__ = 'asset_ln_type'
    __table_args__ = {'schema': 'gridop'}

    asset_ln_type_id = Column('asset_ln_type_id', Integer, primary_key=True)
    asset_ln_type_dscr = Column('asset_ln_type_dscr', String(50))

    def __repr__(self):
        return '<AssetLnType(Asset Line Type ID={0}, Asset Line Type Description={1})>'.format(self.asset_ln_type_id,
                                                                                               self.asset_ln_type_dscr)


class CountyType(Base):
    __tablename__ = 'cnty_type'
    __table_args__ = {'schema': 'gridop'}

    cnty_type_nbr = Column('cnty_type_nbr', Integer, nullable=False, primary_key=True)
    cnty_type_nm = Column('cnty_type_nm', String(50))

    def __repr__(self):
        return '<CountyType(County Number: {0}, County Name: {1})'.format(self.cnty_type_nbr, self.cnty_type_nm)


class CrdnlDrctType(Base):
    __tablename__ = 'crdnl_drct_type'
    __table_args__ = {'schema': 'gridop'}

    crdnl_drct_type_id = Column('crdnl_drct_type_id', Integer, nullable=False, primary_key=True)
    crdnl_drct_type_cd = Column('crdnl_drct_type_cd', String(2))
    crdnl_drct_type_dscr = Column('crdnl_drct_type_dscr', String(255))

    def __repr__(self):
        return '<CrdnlDrctType(Cardinal Direction ID: {0}, Cardinal Direction Code: {1})'.format(
            self.crdnl_drct_type_id,
            self.crdnl_drct_type_cd
        )


class CurveClassType(Base):
    __tablename__ = 'curv_class_type'
    __table_args__ = {'schema': 'gridop'}

    curv_class_type_id = Column(Integer, primary_key=True, nullable=False)
    curv_class_type_cd = Column(String(2))
    curv_class_type_dscr = Column(String(255))

    def __repr__(self):
        return '<CurveClassType(Curve Class Type ID={0}, Curve Class Type Description={1})'.format(
            self.curv_class_type_id, self.curv_class_type_dscr)


class LeftTurnLaneType(Base):
    __tablename__ = 'lt_turn_lane_type'
    __table_args__ = {'schema': 'gridop'}

    lt_turn_lane_type_id = Column(Integer, primary_key=True, nullable=False)
    lt_turn_lane_type_cd = Column(String(2))
    lt_turn_lane_type_dscr = Column(String(255))

    def __repr__(self):
        return '<LeftTurnLaneType(Left Turn Lane Type ID={0}, Left Turn Lane Type Description={1})'.format(
            self.lt_turn_lane_type_id, self.lt_turn_lane_type_dscr)


class RdbdType(Base):
    __tablename__ = 'rdbd_type'
    __table_args__ = {'schema': 'gridop'}

    rdbd_type_id = Column('rdbd_type_id', Integer, primary_key=True)
    rdbd_type_dscr = Column('rdbd_type_dscr', String(255))

    def __repr__(self):
        return '<RdbdType(Roadbed Type ID={0}, Roadbed Type Description={1})>'.format(
            self.rdbd_type_id,
            self.rdbd_type_dscr)


class RightTurnLaneType(Base):
    __tablename__ = 'rt_turn_lane_type'
    __table_args__ = {'schema': 'gridop'}

    rt_turn_lane_type_id = Column(Integer, primary_key=True, nullable=False)
    rt_turn_lane_type_cd = Column(String(2))
    rt_turn_lane_type_dscr = Column(String(255))

    def __repr__(self):
        return '<RightTurnLaneType(Right Turn Lane Type ID={0}, Right Turn Lane Type Description={1})'.format(
            self.rt_turn_lane_type_id, self.rt_turn_lane_type_dscr)


class RtePrfxType(Base):
    __tablename__ = 'rte_prfx_type'
    __table_args__ = {'schema': 'gridop'}

    rte_prfx_type_id = Column('rte_prfx_type_id', Integer, primary_key=True)
    rte_prfx_type_cd = Column('rte_prfx_type_cd', String(2))
    rte_prfx_type_dscr = Column('rte_prfx_type_dscr', String(255))

    def __repr__(self):
        return '<RtePrfxType(Route Prefix Code={0}, Route Suffix Description={1})>'.format(self.rte_prfx_type_id,
                                                                                           self.rte_prfx_type_dscr)


class RteSfxType(Base):
    __tablename__ = 'rte_sfx_type'
    __table_args__ = {'schema': 'gridop'}

    rte_sfx_type_id = Column('rte_sfx_type_id', Integer, primary_key=True)
    rte_sfx_type_dscr = Column('rte_sfx_type_dscr', String(255))

    def __repr__(self):
        return '<RteSfxType(Route Suffix Code={0}, Route Suffix Description={1})>'.format(self.rte_sfx_type_id,
                                                                                          self.rte_sfx_type_dscr)


class SurfaceType(Base):
    __tablename__ = 'srfc_type_id'
    __table_args__ = {'schema': 'gridop'}

    srfc_type_id = Column(Integer, primary_key=True)
    srfc_type_dscr = Column(String(2))

    def __repr__(self):
        return '<SurfaceTypeID(Surface Type ID={0}, Description={1}'.format(self.srfc_type_id, self.srfc_type_dscr)


class StPrfxType(Base):
    __tablename__ = 'st_prfx_type'
    __table_args__ = {'schema': 'gridop'}

    st_prfx_type_id = Column('st_prfx_type_id', Integer, nullable=False, primary_key=True)
    st_prfx_type_cd = Column('st_prfx_type_cd', String(2))
    st_prfx_type_dscr = Column('st_prfx_type_dscr', String(255))

    def __repr__(self):
        return '<StPrfxType(Street Prefix ID: {0}, Street Prefix Code: {1})'.format(self.st_prfx_type_id,
                                                                                    self.st_prfx_type_cd)


class StSfxType(Base):
    __tablename__ = 'st_sfx_type'
    __table_args__ = {'schema': 'gridop'}

    st_sfx_type_id = Column('st_sfx_type_id', Integer, nullable=False, primary_key=True)
    st_sfx_type_cd = Column('st_sfx_type_cd', String(2))
    st_sfx_type_dscr = Column('st_sfx_type_dscr', String(255))

    def __repr__(self):
        return '<StSfxType(Street Suffix ID: {0}, Street Suffix Code: {1})'.format(self.st_sfx_type_id,
                                                                                   self.st_sfx_type_cd)


class VertGradeType(Base):
    __tablename__ = 'vert_grade_type'
    __table_args__ = {'schema': 'gridop'}

    vert_grade_type_id = Column(Integer, nullable=False, primary_key=True)
    vert_grade_type_cd = Column(String(length=2), nullable=False)
    vert_grade_type_dscr = Column(String(length=255))
    vert_grade_type_class_nbr = Column(Integer)
    vert_grade_type_ordr_nbr = Column(Integer)
    vert_grade_type_eff_start_dt = Column(Date)
    vert_grade_type_eff_end_dt = Column(Date)

    def __repr__(self):
        return '<VertGradeType(Vert Grade Type ID: {0}, Vert Grade Type Code: {1}, ' \
               'Vert Grade Type Description: {2})'.format(self.vert_grade_type_id, self.vert_grade_type_cd,
                                                          self.vert_grade_type_dscr)


# Primary Tables


class Asset(Base):
    __tablename__ = 'asset'
    __table_args__ = {'schema': 'gridop'}

    asset_id = Column('asset_id', Integer, primary_key=True)
    rdbd_gmtry_ln_id = Column('rdbd_gmtry_ln_id', Integer)

    def __repr__(self):
        return '<Asset(Asset ID={0}, GID={1}'.format(self.asset_id, self.rdbd_gmtry_ln_id)


class AssetLn(Base):
    __tablename__ = 'asset_ln'
    __table_args__ = {'schema': 'gridop'}

    asset_id = Column('asset_id', Integer, ForeignKey(Asset.asset_id), primary_key=True)
    asset_ln_type_id = Column('asset_ln_type_id', Integer, ForeignKey(AssetLnType.asset_ln_type_id))
    asset_ln_begin_lat = Column('asset_ln_begin_lat', Float(precision=8))
    asset_ln_begin_lon = Column('asset_ln_begin_lon', Float(precision=8))
    asset_ln_end_lat = Column('asset_ln_end_lat', Float(precision=8))
    asset_ln_end_lon = Column('asset_ln_end_lon', Float(precision=8))
    asset_ln_begin_dfo_ms = Column('asset_ln_begin_dfo_ms', Float(precision=3))
    asset_ln_end_dfo_ms = Column('asset_ln_end_dfo_ms', Float(precision=3))

    def __repr__(self):
        return '<AssetLn(Asset Ln={0}'.format(self.asset_id)


class CattleGuard(Base):
    __tablename__ = 'cattl_grd'
    __table_args__ = {'schema': 'gridop'}

    asset_id = Column('asset_id', Integer, nullable=False, primary_key=True)
    intsect_algn_type_id = Column('intsect_algn_type_id', Integer, nullable=True)
    feat_grade_type_id = Column('feat_grade_type_id', Integer, nullable=True)
    crs_feat_grade_id = Column('crs_feat_grade_id', Integer, nullable=True)
    intsect_type_id = Column('intsect_type_id', Integer, nullable=True)
    crs_angl = Column('crs_angl', Integer, nullable=True)
    brdg_id = Column('brdg_id', Integer, nullable=True)

    def __repr__(self):
        return '<CattleGuard(ASSET_ID={0})>'.format(self.asset_id)


# HPMS Samples


class HPMSSample(Base):
    __tablename__ = 'hpms_samp'
    __table_args__ = {'schema': 'gridop'}

    asset_id = Column(Integer, nullable=False, primary_key=True)
    hpms_samp_nbr = Column(Integer, nullable=False)
    hpms_samp_begin_termnus_desc = Column(String(length=64))
    hpms_samp_end_termnus_desc = Column(String(length=64))
    hpms_samp_ret_dt = Column(Date)

    def __repr__(self):
        return '<HPMS Sample(ASSET_ID={0}, HPMS_SAMP_NBR={1})>'.format(self.asset_id, self.hpms_samp_nbr)


class CurvClass(Base):
    __tablename__ = 'curv_class'
    __table_args__ = {'schema': 'gridop'}

    asset_id = Column(Integer, nullable=False, primary_key=True)
    hpms_sample_id = Column(Integer, ForeignKey(HPMSSample.asset_id))
    curv_class_type_id = Column(Integer, ForeignKey(CurveClassType.curv_class_type_id))
    curve_class_lngth_ms = Column(Float(3))

    def __repr__(self):
        return '<Curve Class(ASSET_ID={0}, HPMS Sample Number={1}, ' \
               'Curve Class Type ID={2})'.format(self.asset_id,
                                                 self.hpms_sample_id,
                                                 self.curv_class_type_id)


class VertGrade(Base):
    __tablename__ = 'vert_grade'
    __table_args__ = {'schema': 'gridop'}

    asset_id = Column(Integer, nullable=False, primary_key=True)
    hpms_sample_id = Column(Integer, ForeignKey("HPMSSample.asset_id"), nullable=False)
    vert_grade_type_id = Column(Integer, ForeignKey(VertGradeType.vert_grade_type_id), nullable=False)
    vert_grade_lngth_ms = Column(Float(3))

    def __repr__(self):
        return 'Vertical Grade(ASSET_ID={0}, HPMS Sample Number={1}, ' \
               'Vertical Grade Type ID={2})'.format(self.asset_id,
                                                    self.hpms_sample_id,
                                                    self.vert_grade_type_id)


class JobInfo(Base):
    __tablename__ = 'job_info'
    __table_args__ = {'schema': 'gridop'}

    job_id = Column(Integer, primary_key=True)
    job_info_type = Column(String(2000))
    job_info_jl_flag = Column(Integer)
    job_info_nm = Column(String(80))
    job_info_dscr = Column(String(2000))
    job_info_cmnt = Column(String(2000))
    job_info_create_user_id = Column(String(80))
    job_info_maintn_user_id = Column(String(80))
    job_info_revw_user_id = Column(String(80))
    job_info_rte_id = Column(Integer)
    job_info_jl_beg_dfo = Column(Float(precision=6))
    job_info_jl_end_dfo = Column(Float(precision=6))
    job_info_jl_beg_lat = Column(Float(precision=8))
    job_info_jl_beg_lon = Column(Float(precision=8))
    job_info_jl_end_lat = Column(Float(precision=8))
    job_info_jl_end_lon = Column(Float(precision=8))
    job_info_ur_beg_dfo = Column(Float(precision=6))
    job_info_ur_end_dfo = Column(Float(precision=6))
    job_info_ur_beg_lat = Column(Float(precision=8))
    job_info_ur_beg_lon = Column(Float(precision=8))
    job_info_ur_end_lat = Column(Float(precision=8))
    job_info_ur_end_lon = Column(Float(precision=8))
    job_info_plans_url = Column(String(256))
    job_info_plans_csj = Column(String(32))
    job_info_district_id = Column(Integer)

    def __repr__(self):
        return '<JobInfo(Job ID={0}, DFO={1}>'.format(self.job_id,
                                                      self.job_info_dscr)


class LeftTurnLane(Base):
    __tablename__ = 'lt_turn_lane'
    __table_args__ = {'schema': 'gridop'}

    asset_id = Column(Integer, primary_key=True)
    lt_turn_lane_type_id = Column(Integer, ForeignKey(LeftTurnLaneType.lt_turn_lane_type_id))

    def __repr__(self):
        return '<LeftTurnLane(asset_id={0}, Left Turn Lane Type={1}, ' \
               'Left Turn Lane Description={2}>'.format(self.asset_id, self.lt_turn_lane_type_id)


class ReferenceMarker(Base):
    __tablename__ = 'rmrkr_pnt'
    __table_args__ = {'schema': 'gridop'}

    rmrkr_pnt_id = Column(Integer, primary_key=True)
    rmrkr_pnt_nbr = Column(String(4))
    rmrkr_pnt_sfx_cd = Column(String(1), nullable=True)
    rdbd_gmtry_ln_id = Column(Integer)
    rdbd_type_id = Column(Integer)
    rmrkr_pnt_dt = Column(Date)
    rmrkr_pnt_lat = Column(Float(precision=8), nullable=True)
    rmrkr_pnt_lon = Column(Float(precision=8), nullable=True)
    rmrkr_pnt_edit_dt = Column(Date)
    rmrkr_pnt_edit_user_nm = Column(String(length=50))
    rmrkr_pnt_create_dt = Column(Date)
    rmrkr_pnt_create_user_nm = Column(String(length=50))
    rmrkr_pnt_eff_start_dt = Column(Date)
    rmrkr_pnt_eff_end_dt = Column(Date)
    objectid = Column(Integer)
    rmrkr_updt_type_id = Column(Integer)
    rmrkr_pnt_dfo_ms = Column(Float(precision=3))
    stat_indctr = Column(String(length=10))

    def __repr__(self):
        return '<ReferenceMarker(Route={0}, DFO={1}, MarkerNumber={2})>'.format(self.rdbd_gmtry_ln_id,
                                                                                self.rmrkr_pnt_dfo_ms,
                                                                                self.rmrkr_pnt_dfo_ms)


class RightTurnLane(Base):
    __tablename__ = 'rt_turn_lane'
    __table_args__ = {'schema': 'gridop'}

    asset_id = Column(Integer, primary_key=True)
    rt_turn_lane_type_id = Column(Integer, ForeignKey(RightTurnLaneType.rt_turn_lane_type_id))

    def __repr__(self):
        return '<RightTurnLane(asset_id={0}, Right Turn Lane Type={1}, ' \
               'Right Turn Lane Description={2}>'.format(self.asset_id, self.rt_turn_lane_type_id)


class RoadbedSurface(Base):
    __tablename__ = 'rdbd_srfc'
    __table_args__ = {'schema': 'gridop'}

    asset_id = Column(Integer, primary_key=True)
    srfc_type_id = Column(Integer, ForeignKey(SurfaceType.srfc_type_id))

    def __repr__(self):
        return '<RoadbedSurface(asset_id={0}, SurfaceTypeID={1}, \
                                SurfaceTypeDescription={2}'.format(self.asset_id,
                                                                   self.srfc_type_id,
                                                                   SurfaceType.srfc_type_dscr)


class Rte(Base):
    __tablename__ = 'rte'
    __table_args__ = {'schema': 'gridop'}

    rte_id = Column('rte_id', Integer, primary_key=True, unique=True)
    rte_nbr = Column('rte_nbr', String(10))
    rte_prfx_type_id = Column('rte_prfx_type_id', Integer, ForeignKey(RtePrfxType.rte_prfx_type_id))
    rte_sfx_type_id = Column('rte_sfx_type_id', Integer, ForeignKey(RteSfxType.rte_sfx_type_id))
    rte_eff_start_dt = Column('rte_eff_start_dt', Date)
    rte_eff_end_dt = Column('rte_eff_end_dt', Date)
    cnty_type_nbr = Column('cnty_type_nbr', Integer)

    def __repr__(self):
        return '<Rte(Route ID={0})>'.format(self.rte_id)


class RteDefnLn(Base):
    __tablename__ = 'rte_defn_ln'
    __table_args__ = {'schema': 'gridop'}

    rte_defn_ln_id = Column('rte_defn_ln_id', Integer, primary_key=True, unique=True)
    rdbd_gmtry_ln_id = Column('rdbd_gmtry_ln_id', Integer)
    rte_id = Column('rte_id', Integer, ForeignKey(Rte.rte_id))
    rte_defn_ln_ms = Column('rte_defn_ln_ms', Float(precision=8), nullable=True)
    rdbd_type_id = Column('rdbd_type_id', Integer)
    crdnl_drct_type_id = Column('crdnl_drct_type_id', Integer)
    rte_def_type_id = Column('rte_def_type_id', Integer)
    rte_defn_ln_nm = Column('rte_defn_ln_nm', String(17), nullable=True)
    rte_defn_ln_prmry_flag = Column('rte_defn_ln_prmry_flag', Integer, nullable=True)
    rte_defn_ln_mlge_rev_flag = Column('rte_defn_ln_mlge_rev_flag', Integer, nullable=True)
    rte_defn_ln_begin_lat = Column('rte_defn_ln_begin_lat', Float(precision=8), nullable=True)
    rte_defn_ln_begin_lon = Column('rte_defn_ln_begin_lon', Float(precision=8), nullable=True)
    rte_defn_ln_end_lat = Column('rte_defn_ln_end_lat', Float(precision=8), nullable=True)
    rte_defn_ln_end_lon = Column('rte_defn_ln_end_lon', Float(precision=8), nullable=True)
    rte_defn_ln_edit_dt = Column('rte_defn_ln_edit_dt', Date, nullable=True)
    rte_defn_ln_edit_user_nm = Column('rte_defn_ln_edit_user_nm', String(50), nullable=True)
    rte_defn_ln_create_dt = Column('rte_defn_ln_create_dt', Date)
    rte_defn_ln_create_user_nm = Column('rte_defn_ln_create_user_nm', String(50))
    rte_defn_ln_eff_start_dt = Column('rte_defn_ln_eff_start_dt', Date, nullable=True)
    rte_defn_ln_eff_end_dt = Column('rte_defn_ln_eff_end_dt', Date, nullable=True)
    objectid = Column('objectid', Integer)
    rte_defn_ln_begin_dfo_ms = Column('rte_defn_ln_begin_dfo_ms', Float(precision=3), nullable=True)
    rte_defn_ln_end_dfo_ms = Column('rte_defn_ln_end_dfo_ms', Float(precision=3), nullable=True)
    stat_indctr = Column('stat_indctr', String(10), nullable=True)

    def __repr__(self):
        return '<RteDefnLn(Route Definition Line ID={0}, Route ID={1})>'.format(self.rte_defn_ln_id, self.rte_id)
