import os
import sys, argparse
import time
import logging
import csv
import cx_Oracle
import sqlite3
import connections

class TableActions(object):
    '''
    This class will provide the actions for the backup process
    '''
    def __init__(self, o_cursed, s_cursed):
        '''
        args:
            o_cursed = GRID cursor
            s_cursed = sqlite cursor
        '''
        self.o_cursed = o_cursed
        self.s_cursed = s_cursed

    def etl_job_sched(self):
        table_exist = '''
            SELECT COUNT(*) FROM sqlite_master WHERE type = 'table' AND name = 'ETL_JOB_SCHED'
        '''
        create_sql = '''
            CREATE TABLE ETL_JOB_SCHED (
                ETL_SCHED_ID INTEGER PRIMARY KEY NOT NULL,
                BATCH_JOB_ID INTEGER,
                FILENAME VARCHAR(100),
                STAT VARCHAR(15),
                TS DATETIME,
                UPLD_BY VARCHAR(50),
                SCHED_TYPE VARCHAR(5)
            )
        '''
        select_sql = '''
            SELECT GRIDOP.ETL_JOB_SCHED.ETL_JOB_SCHED_ID                                       AS ETL_SCHED_ID,
                GRIDOP.ETL_JOB_SCHED.ETL_JOB_SCHED_BATCH_JOB_ID                                  AS BATCH_JOB_ID,
                SUBSTR(GRIDOP.ETL_JOB_SCHED.ETL_JOB_SCHED_FILENAME, INSTR(GRIDOP.ETL_JOB_SCHED.ETL_JOB_SCHED_FILENAME, '/', -1) + 1) AS FILENAME,
                GRIDOP.ETL_JOB_SCHED.ETL_JOB_SCHED_STAT                                          AS STAT,
                GRIDOP.ETL_JOB_SCHED.ETL_JOB_SCHED_TS                                            AS TS,
                GRIDOP.ETL_JOB_SCHED.ETL_JOB_SCHED_UPLD_BY                                       AS UPLD_BY,
                GRIDOP.ETL_JOB_SCHED.ETL_JOB_SCHED_TYPE                                          AS SCHED_TYPE
            FROM GRIDOP.ETL_JOB_SCHED
        '''
        update_sql = '''
            UPDATE ETL_JOB_SCHED
            SET BATCH_JOB_ID=?,
                FILENAME=?,
                STAT=?,
                TS=?,
                UPLD_BY=?,
                SCHED_TYPE=?
            WHERE ETL_SCHED_ID=?
        '''
        insert_sql = '''
            INSERT INTO ETL_JOB_SCHED
            SELECT ?,?,?,?,?,?,?
            WHERE changes() = 0        
        '''

        count = int(self.s_cursed.execute(table_exist).fetchone()[0])
        if count == 0:
            logging.info('Creating ETL_JOB_SCHED Table')
            for query in create_sql.split(';'):
                self.s_cursed.execute(query)
        
        logging.info('Upserting to ETL_JOB_SCHED')
        results = self.o_cursed.execute(select_sql)
        for row in results:
            self.s_cursed.execute(update_sql,(row[1],row[2],row[3],row[4],row[5],row[6],row[0]))
            self.s_cursed.execute(insert_sql, row)
            
    def etl_job_err(self):
        table_exist = '''
            SELECT COUNT(*) FROM sqlite_master WHERE type = 'table' AND name = 'ETL_JOB_ERR'
        '''
        create_sql = '''
            CREATE TABLE ETL_JOB_ERR (
                ETL_JOB_ERR_ID INTEGER PRIMARY KEY NOT NULL,
                ERR_DESC TEXT,
                ERR_TYPE VARCHAR(5) NOT NULL,
                ETL_SCHED_ID INTEGER NOT NULL,
                OBJ_ID INTEGER NOT NULL,
                OBJ_TYPE VARCHAR(100) NOT NULL,
                OBJ_SUBTYPE INTEGER NOT NULL,
                FOREIGN KEY (ETL_SCHED_ID) REFERENCES ETL_JOB_SCHED(ETL_SCHED_ID) ON DELETE CASCADE
            );
            CREATE INDEX err_etl_sched_id ON ETL_JOB_ERR(ETL_SCHED_ID);
        '''
        select_sql = '''
            SELECT GRIDOP.ETL_JOB_ERR.ETL_JOB_ERR_ID,
                GRIDOP.ETL_JOB_ERR.ETL_JOB_ERR_DESC           AS ERR_DESC,
                GRIDOP.ETL_JOB_ERR.ETL_JOB_ERR_TYPE           AS ERR_TYPE,
                GRIDOP.ETL_JOB_ERR.ETL_JOB_ERR_JOB_ID         AS ETL_SCHED_ID,
                GRIDOP.ETL_JOB_ERR.ETL_JOB_ERR_OBJECT_ID      AS OBJ_ID,
                GRIDOP.ETL_JOB_ERR.ETL_JOB_ERR_OBJECT_TYPE    AS OBJ_TYPE,
                GRIDOP.ETL_JOB_ERR.ETL_JOB_ERR_OBJECT_SUBTYPE AS OBJ_SUBTYPE
            FROM GRIDOP.ETL_JOB_ERR
        '''
        update_sql = '''
            UPDATE ETL_JOB_ERR
            SET ERR_DESC=?,
                ERR_TYPE=?,
                ETL_SCHED_ID=?,
                OBJ_ID=?,
                OBJ_TYPE=?,
                OBJ_SUBTYPE=?
            WHERE ETL_JOB_ERR_ID=?
        '''
        insert_sql = '''
            INSERT INTO ETL_JOB_ERR
            SELECT ?,?,?,?,?,?,?
            WHERE changes() = 0
        '''
        
        count = int(self.s_cursed.execute(table_exist).fetchone()[0])
        if count == 0:
            logging.info('Creating ETL_JOB_ERR Table')
            for query in create_sql.split(';'):
                self.s_cursed.execute(query)
    
        logging.info('Upserting to ETL_JOB_ERR')
        results = self.o_cursed.execute(select_sql)
        for row in results:
            self.s_cursed.execute(update_sql,(row[1],row[2],row[3],row[4],row[5],row[6],row[0]))
            self.s_cursed.execute(insert_sql, row)
            
    def job_info(self):
        table_exist = '''
            SELECT COUNT(*) FROM sqlite_master WHERE type = 'table' AND name = 'JOB_INFO'
        '''
        create_sql = '''
            CREATE TABLE JOB_INFO (
                JOB_ID INTEGER PRIMARY KEY NOT NULL,
                JOB_TYPE CHAR(3)NOT NULL,
                RTE_ID INTEGER,
                RTE_PRFX CHAR(2),
                RTE_NBR VARCHAR(10),
                RTE_SFX CHAR(2),
                COUNTY VARCHAR(50),
                BEG_DFO NUMERIC(10,6),
                END_DFO NUMERIC(10,6),
                JOB_LOCK INTEGER(1) NOT NULL,
                JOB_NM VARCHAR(80),
                JOB_DSCR TEXT NOT NULL,
                JOB_CMNT TEXT,
                CREATOR VARCHAR(80),
                MAINTAINER VARCHAR(80),
                REVIEWER VARCHAR(80),
                PLANS_URL VARCHAR(255),
                PLANS_CSJ VARCHAR(32),
                DISTRICT INTEGER(2),
                ETL_SCHED_ID INTEGER,
                FOREIGN KEY (ETL_SCHED_ID) REFERENCES ETL_JOB_SCHED(ETL_SCHED_ID) ON DELETE CASCADE
            );
            CREATE INDEX info_etl_sched_id ON JOB_INFO(ETL_SCHED_ID);
            SELECT AddGeometryColumn('JOB_INFO','SHAPE_LN',4269,'GEOMETRY','XY',0);
            SELECT CreateSpatialIndex('JOB_INFO', 'SHAPE_LN');
        '''    
        select_sql = '''
            SELECT GRIDOP.JOB_INFO.JOB_ID,
                GRIDOP.JOB_INFO.JOB_INFO_TYPE         AS JOB_TYPE,
                GRIDOP.JOB_INFO.JOB_INFO_RTE_ID       AS RTE_ID,
                GRIDOP.RTE_PRFX_TYPE.RTE_PRFX_TYPE_CD AS RTE_PRFX,
                GRIDOP.RTE.RTE_NBR,
                GRIDOP.RTE_SFX_TYPE.RTE_SFX_TYPE_CD     AS RTE_SFX,
                GRIDOP.CNTY_TYPE.CNTY_TYPE_NM           AS COUNTY,
                GRIDOP.JOB_INFO.JOB_INFO_UR_BEG_DFO     AS BEG_DFO,
                GRIDOP.JOB_INFO.JOB_INFO_UR_END_DFO     AS END_DFO,
                GRIDOP.JOB_INFO.JOB_INFO_JL_FLAG        AS JOB_LOCK,
                GRIDOP.JOB_INFO.JOB_INFO_NM             AS JOB_NM,
                GRIDOP.JOB_INFO.JOB_INFO_DSCR           AS JOB_DSCR,
                GRIDOP.JOB_INFO.JOB_INFO_CMNT           AS JOB_CMNT,
                GRIDOP.JOB_INFO.JOB_INFO_CREATE_USER_ID AS CREATOR,
                GRIDOP.JOB_INFO.JOB_INFO_MAINTN_USER_ID AS MAINTAINER,
                GRIDOP.JOB_INFO.JOB_INFO_REVW_USER_ID   AS REVIEWER,
                GRIDOP.JOB_INFO.JOB_INFO_PLANS_URL      AS PLANS_URL,
                GRIDOP.JOB_INFO.JOB_INFO_PLANS_CSJ      AS PLANS_CSJ,
                GRIDOP.JOB_INFO.JOB_INFO_DISTRICT_ID    AS DISTRICT,
                GRIDOP.JOB_INFO.ETL_JOB_SCHED_ID        AS ETL_SCHED_ID,
                CASE
                    WHEN val.SHAPE_VALIDATE = '13011' THEN NULL
                    ELSE SDO_UTIL.TO_WKTGEOMETRY(GRIDOP.JOB_INFO.SHAPE)
                END                                                       AS SHAPE_LN
            FROM GRIDOP.JOB_INFO
            LEFT JOIN GRIDOP.RTE
            ON GRIDOP.JOB_INFO.JOB_INFO_RTE_ID = GRIDOP.RTE.RTE_ID
            LEFT JOIN GRIDOP.RTE_PRFX_TYPE
            ON GRIDOP.RTE_PRFX_TYPE.RTE_PRFX_TYPE_ID = GRIDOP.RTE.RTE_PRFX_TYPE_ID
            LEFT JOIN GRIDOP.RTE_SFX_TYPE
            ON GRIDOP.RTE_SFX_TYPE.RTE_SFX_TYPE_ID = GRIDOP.RTE.RTE_SFX_TYPE_ID
            LEFT JOIN GRIDOP.CNTY_TYPE
            ON GRIDOP.RTE.CNTY_TYPE_NBR = GRIDOP.CNTY_TYPE.CNTY_TYPE_NBR
            LEFT JOIN 
                (SELECT ji.JOB_ID,
                    SDO_GEOM.VALIDATE_GEOMETRY(ji.SHAPE, m.diminfo) AS SHAPE_VALIDATE
                FROM  GRIDOP.JOB_INFO ji, all_sdo_geom_metadata m
                WHERE m.table_name = 'JOB_INFO' AND m.column_name = 'SHAPE') val
            ON val.JOB_ID = GRIDOP.JOB_INFO.JOB_ID
        '''
        update_sql = '''
            UPDATE JOB_INFO
            SET JOB_LOCK=?,
                JOB_CMNT=?,
                PLANS_URL=?,
                PLANS_CSJ=?
            WHERE JOB_ID=?
        '''
        insert_sql = '''
            INSERT INTO JOB_INFO
            SELECT ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,? ,GeomFromText(?,4269)
            WHERE changes() = 0
        '''

        count = int(self.s_cursed.execute(table_exist).fetchone()[0])
        if count == 0:
            logging.info('Creating JOB_INFO Table')
            for query in create_sql.split(';'):
                self.s_cursed.execute(query)
    
        logging.info('Upserting to JOB_INFO')
        results = self.o_cursed.execute(select_sql)
        for row in results:
            #re-create row, turning CLOB data from Oracle into Pythoon strings; needed for SQLite insert; could not perform with PL/SQL due to database memory constraints.
            row = (row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9],row[10],row[11],row[12],row[13],row[14],row[15],row[16],row[17],row[18],row[19],str(row[20]))
            self.s_cursed.execute(update_sql,(row[9],row[12],row[16],row[17],row[0]))
            self.s_cursed.execute(insert_sql,row)
            
    def job_data_pnt(self):
        table_exist = '''
            SELECT COUNT(*) FROM sqlite_master WHERE type = 'table' AND name = 'JOB_DATA_PNT'
        '''
        create_sql = '''
            CREATE TABLE JOB_DATA_PNT (
                JOB_DATA_ID INTEGER PRIMARY KEY NOT NULL,
                JOB_ID INTEGER,
                RDBD_GMTRY_LN_ID INTEGER,
                RTE_DEFN_LN_NM VARCHAR(17),
                BEGIN_DFO NUMERIC(11,8),
                END_DFO NUMERIC(11,8),
                ASSET_ID INTEGER,
                CTRL_SECT_LN_ID INTEGER,
                RMRKR_PNT_ID INTEGER,
                RTE_DEFN_LN_ID INTEGER,
                JOB_DATA_STATUS VARCHAR(32),
                DATA_TYPE TEXT,
                DATA_TABLE TEXT,
                SERIALIZED_DATA TEXT,
                DEL_DATE DATETIME,
                STAT_INDCTR VARCHAR(10),
                FOREIGN KEY (JOB_ID) REFERENCES JOB_INFO(JOB_ID) ON DELETE CASCADE
            );
            CREATE INDEX data_pnt_job_id ON JOB_DATA_PNT(JOB_ID);
            SELECT AddGeometryColumn('JOB_DATA_PNT','SHAPE',4269,'GEOMETRY','XY',0);
            SELECT CreateSpatialIndex('JOB_DATA_PNT', 'SHAPE');
        '''
        select_sql = '''
            SELECT jd.JOB_DATA_ID,
              jd.JOB_ID,
              jd.RDBD_GMTRY_LN_ID,
              rdl.RTE_DEFN_LN_NM,
              jd.BEGIN_DFO,
              jd.END_DFO,
              jd.ASSET_ID,
              jd.CTRL_SECT_LN_ID,
              jd.RMRKR_PNT_ID,
              jd.RTE_DEFN_LN_ID,
              jd.JOB_DATA_STATUS,
              CONCAT(GRIDOP.ASSET_PNT_TYPE.ASSET_PNT_TYPE_DSCR, GRIDOP.LRS_TYPE.LRS_TYPE_DSCR) AS DATA_TYPE,
              CONCAT(GRIDOP.ASSET_PNT_TYPE.ASSET_PNT_TYPE_TABLE, GRIDOP.LRS_TYPE.LRS_TYPE_CD) AS DATA_TABLE,
              TO_CHAR(jd.JOB_DATA_SERIALIZED_DATA) AS SERIALIZED_DATA,
              jd.JOB_DATA_DEL_DATE AS DEL_DATA,
              jd.STAT_INDCTR,
              jd.SHAPE_PNT AS SHAPE
            FROM GRIDOP.JOB_DATA jd
            LEFT JOIN GRIDOP.ASSET_PNT_TYPE
            ON GRIDOP.ASSET_PNT_TYPE.ASSET_PNT_TYPE_ID = jd.ASSET_PNT_TYPE_ID
            LEFT JOIN GRIDOP.LRS_TYPE
            ON GRIDOP.LRS_TYPE.LRS_TYPE_ID = jd.LRS_TYPE_ID
            LEFT JOIN
              (SELECT GRIDOP.RTE_DEFN_LN.RDBD_GMTRY_LN_ID,
                GRIDOP.RTE_DEFN_LN.RTE_DEFN_LN_NM
              FROM GRIDOP.RTE_DEFN_LN
              WHERE GRIDOP.RTE_DEFN_LN.RTE_DEFN_LN_PRMRY_FLAG = 1
              ) rdl
            ON jd.RDBD_GMTRY_LN_ID    = rdl.RDBD_GMTRY_LN_ID
            WHERE jd.JOB_DATA_STATUS <> 'UNMODIFIED'
              AND (jd.ASSET_PNT_TYPE_ID IS NOT NULL
                    OR jd.LRS_TYPE_ID = 2)
        '''
        update_sql = '''
            UPDATE JOB_DATA_PNT
            SET BEGIN_DFO=?,
                END_DFO=?,
                JOB_DATA_STATUS=?,
                SERIALIZED_DATA=?,
                SHAPE=GeomFromText(?,4269)
            WHERE JOB_DATA_ID=?
        '''
        insert_sql = '''
            INSERT INTO JOB_DATA_PNT
            SELECT ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,GeomFromText(?,4269)
            WHERE changes() = 0
        '''

        count = int(self.s_cursed.execute(table_exist).fetchone()[0])
        if count == 0:
            logging.info('Creating JOB_DATA_PNT Table')
            for query in create_sql.split(';'):
                self.s_cursed.execute(query)
        
        logging.info('Upserting to JOB_DATA_PNT')
        results = self.o_cursed.execute(select_sql)
        for row in results:
            row = (row[0],row[1],row[2],row[3],row[4],str(row[5]),row[6],row[7],row[8],row[9],row[10],row[11],row[12],str(row[13]),row[14],row[15],str(row[16]))
            self.s_cursed.execute(update_sql,(row[4], row[5], row[10], row[13], row[16], row[0]))
            self.s_cursed.execute(insert_sql, row)
            
    def job_data_ln(self):
        table_exist = '''
            SELECT COUNT(*) FROM sqlite_master WHERE type = 'table' AND name = 'JOB_DATA_LN'
        '''
        create_sql = '''
            CREATE TABLE JOB_DATA_LN (
                JOB_DATA_ID INTEGER PRIMARY KEY NOT NULL,
                JOB_ID INTEGER,
                RDBD_GMTRY_LN_ID INTEGER,
                RTE_DEFN_LN_NM VARCHAR(17),
                BEGIN_DFO NUMERIC(11,8),
                END_DFO NUMERIC(11,8),
                ASSET_ID INTEGER,
                CTRL_SECT_LN_ID INTEGER,
                RMRKR_PNT_ID INTEGER,
                RTE_DEFN_LN_ID INTEGER,
                JOB_DATA_STATUS VARCHAR(32),
                DATA_TYPE TEXT,
                DATA_TABLE TEXT,
                SERIALIZED_DATA TEXT,
                DEL_DATE DATETIME,
                STAT_INDCTR VARCHAR(10),
                FOREIGN KEY (JOB_ID) REFERENCES JOB_INFO(JOB_ID) ON DELETE CASCADE
            );
            CREATE INDEX data_ln_job_id ON JOB_DATA_LN(JOB_ID);
            SELECT AddGeometryColumn('JOB_DATA_LN','SHAPE',4269,'GEOMETRY','XY',0);
            SELECT CreateSpatialIndex('JOB_DATA_LN', 'SHAPE');
        '''
        select_sql = '''
            WITH data_ln AS
              (SELECT jd.JOB_DATA_ID,
                jd.JOB_ID,
                jd.RDBD_GMTRY_LN_ID,
                rdl.RTE_DEFN_LN_NM,
                jd.BEGIN_DFO,
                jd.END_DFO,
                jd.ASSET_ID,
                jd.CTRL_SECT_LN_ID,
                jd.RMRKR_PNT_ID,
                jd.RTE_DEFN_LN_ID,
                jd.JOB_DATA_STATUS,
                CONCAT(GRIDOP.ASSET_LN_TYPE.ASSET_LN_TYPE_DSCR, GRIDOP.LRS_TYPE.LRS_TYPE_DSCR) AS DATA_TYPE,
                CONCAT(GRIDOP.ASSET_LN_TYPE.ASSET_LN_TYPE_TABLE, GRIDOP.LRS_TYPE.LRS_TYPE_CD) AS DATA_TABLE,
                TO_CHAR(jd.JOB_DATA_SERIALIZED_DATA) AS SERIALIZED_DATA,
                jd.JOB_DATA_DEL_DATE AS DEL_DATA,
                jd.STAT_INDCTR,
                jd.SHAPE_LN
              FROM GRIDOP.JOB_DATA jd
              LEFT JOIN GRIDOP.ASSET_LN_TYPE
              ON GRIDOP.ASSET_LN_TYPE.ASSET_LN_TYPE_ID = jd.ASSET_LN_TYPE_ID
              LEFT JOIN GRIDOP.LRS_TYPE
              ON GRIDOP.LRS_TYPE.LRS_TYPE_ID = jd.LRS_TYPE_ID
              LEFT JOIN
                (SELECT GRIDOP.RTE_DEFN_LN.RDBD_GMTRY_LN_ID,
                  GRIDOP.RTE_DEFN_LN.RTE_DEFN_LN_NM
                FROM GRIDOP.RTE_DEFN_LN
                WHERE GRIDOP.RTE_DEFN_LN.RTE_DEFN_LN_PRMRY_FLAG = 1
                ) rdl
              ON jd.RDBD_GMTRY_LN_ID    = rdl.RDBD_GMTRY_LN_ID 
              WHERE jd.JOB_DATA_STATUS <> 'UNMODIFIED'
                AND (jd.ASSET_LN_TYPE_ID IS NOT NULL
                      OR jd.LRS_TYPE_ID <> 2)
              ),
            val_ln AS
              (SELECT jd1.JOB_DATA_ID,
                  SDO_GEOM.VALIDATE_GEOMETRY(jd1.SHAPE_LN, m.diminfo) AS SHAPE_LN_VAL
                FROM  GRIDOP.JOB_DATA jd1, all_sdo_geom_metadata m
                WHERE m.table_name = 'JOB_DATA' AND m.column_name = 'SHAPE_LN'
                AND jd1.JOB_DATA_STATUS <>'UNMODIFIED'
                  AND (jd1.ASSET_LN_TYPE_ID IS NOT NULL
                      OR jd1.LRS_TYPE_ID <> 2)    
                )

            SELECT data_ln.JOB_DATA_ID,
                data_ln.JOB_ID,
                data_ln.RDBD_GMTRY_LN_ID,
                data_ln.RTE_DEFN_LN_NM,
                data_ln.BEGIN_DFO,
                data_ln.END_DFO,
                data_ln.ASSET_ID,
                data_ln.CTRL_SECT_LN_ID,
                data_ln.RMRKR_PNT_ID,
                data_ln.RTE_DEFN_LN_ID,
                data_ln.JOB_DATA_STATUS,
                data_ln.DATA_TYPE,
                data_ln.DATA_TABLE,
                data_ln.SERIALIZED_DATA,
                data_ln.DEL_DATA,
                data_ln.STAT_INDCTR,
                CASE WHEN val_ln.SHAPE_LN_VAL = '13011' THEN NULL
                ELSE SDO_UTIL.TO_WKTGEOMETRY(data_ln.SHAPE_LN) END AS SHAPE
              FROM data_ln
            JOIN val_ln
            ON val_ln.JOB_DATA_ID = data_ln.JOB_DATA_ID
        '''
        update_sql = '''
            UPDATE JOB_DATA_LN
            SET BEGIN_DFO=?,
                END_DFO=?,
                JOB_DATA_STATUS=?,
                SERIALIZED_DATA=?,
                SHAPE=GeomFromText(?,4269)
            WHERE JOB_DATA_ID=?
        '''
        insert_sql = '''
            INSERT INTO JOB_DATA_LN
            SELECT ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,GeomFromText(?,4269)
            WHERE changes() = 0
        '''

        count = int(self.s_cursed.execute(table_exist).fetchone()[0])
        if count == 0:
            logging.info('Creating JOB_DATA_LN Table')
            for query in create_sql.split(';'):
                self.s_cursed.execute(query)
        
        logging.info('Upserting to JOB_DATA_LN')
        results = self.o_cursed.execute(select_sql)
        for row in results:
            row = (row[0],row[1],row[2],row[3],row[4],row[5],row[6],row[7],row[8],row[9],row[10],row[11],row[12],row[13],row[14],row[15],str(row[16]))
            #row = (row[0],row[1],row[2],row[3],row[4],str(row[5]),row[6],row[7],row[8],row[9],row[10],row[11],row[12],str(row[13]),row[14],row[15],str(row[16]),)
            self.s_cursed.execute(update_sql,(row[4], row[5], row[10], row[13], row[16], row[0]))
            self.s_cursed.execute(insert_sql, row)

    def job_mod(self):
        table_exist = '''
            SELECT COUNT(*) FROM sqlite_master WHERE type = 'table' AND name = 'JOB_MOD'
        '''
        create_sql = '''
            CREATE TABLE JOB_MOD (
                JOB_MOD_ID INTEGER PRIMARY KEY NOT NULL,
                JOB_ID INTEGER NOT NULL,
                CHNG_ID INTEGER NOT NULL,
                ASSET_TYPE TEXT,
                ASSET_PROP_NM TEXT,
                OLD_VAL TEXT,
                NEW_VAL TEXT,
                PARNT_ADD_OR_DEL CHAR(1),
                JOB_MOD_DT DATETIME,
                USER_ID VARCHAR(32),
                FOREIGN KEY (JOB_ID) REFERENCES JOB_INFO(JOB_ID) ON DELETE CASCADE
            );
            CREATE INDEX mod_job_id ON JOB_MOD(JOB_ID);
        '''
        select_sql = '''
            SELECT GRIDOP.JOB_MOD.JOB_MOD_ID,
                GRIDOP.JOB_MOD.JOB_MOD_JOB_ID           AS JOB_ID,
                GRIDOP.JOB_MOD.JOB_MOD_CHNG_ID          AS CHNG_ID,
                GRIDOP.JOB_MOD.JOB_MOD_ASSET_TYPE       AS ASSET_TYPE,
                GRIDOP.JOB_MOD.JOB_MOD_ASSET_PROP_NM    AS ASSET_PROP_NM,
                GRIDOP.JOB_MOD.JOB_MOD_OLD_VAL          AS OLD_VAL,
                GRIDOP.JOB_MOD.JOB_MOD_NEW_VAL          AS NEW_VAL,
                GRIDOP.JOB_MOD.JOB_MOD_PARNT_ADD_OR_DEL AS PARNT_ADD_OR_DEL,
                GRIDOP.JOB_MOD.JOB_MOD_DT,
                GRIDOP.JOB_MOD.JOB_MOD_USER_ID AS USER_ID
            FROM GRIDOP.JOB_MOD
        '''
        update_sql = '''
            UPDATE JOB_MOD
            SET ASSET_TYPE=?,
                ASSET_PROP_NM=?,
                OLD_VAL=?,
                NEW_VAL=?,
                PARNT_ADD_OR_DEL=?,
                JOB_MOD_DT=?
            WHERE JOB_MOD_ID=?
        '''
        insert_sql = '''
            INSERT INTO JOB_MOD
            SELECT ?,?,?,?,?,?,?,?,?,?
            WHERE changes() = 0
        '''

        count = int(self.s_cursed.execute(table_exist).fetchone()[0])
        if count == 0:
            logging.info('Creating JOB_MOD Table')
            for query in create_sql.split(';'):
                self.s_cursed.execute(query)
        
        logging.info('Upserting to JOB_MOD')
        results = self.o_cursed.execute(select_sql)
        for row in results:
            self.s_cursed.execute(update_sql,(row[3],row[4],row[5],row[6],row[7],row[8],row[0]))
            self.s_cursed.execute(insert_sql, row)
            
    def job_rdbd_info(self):
        table_exist = '''
            SELECT COUNT(*) FROM sqlite_master WHERE type = 'table' AND name = 'JOB_RDBD_INFO'
        '''
        create_sql = '''
            CREATE TABLE JOB_RDBD_INFO (
                JOB_ID INTEGER NOT NULL,
                RTE_DEFN_LN_ID INTEGER NOT NULL,
                RDBD_GMTRY_LN_ID INTEGER NOT NULL,
                RDBD_TYPE_ID INTEGER NOT NULL,
                BEGIN_DFO NUMERIC,
                END_DFO NUMERIC,
                PRIMARY KEY(JOB_ID, RTE_DEFN_LN_ID),
                FOREIGN KEY (JOB_ID) REFERENCES JOB_INFO(JOB_ID) ON DELETE CASCADE
            );
            CREATE INDEX rdbd_job_id ON JOB_RDBD_INFO(JOB_ID);
            SELECT AddGeometryColumn('JOB_RDBD_INFO','SHAPE_LN',4269,'GEOMETRY','XY',0);
            SELECT CreateSpatialIndex('JOB_RDBD_INFO', 'SHAPE_LN');
        '''
        select_sql = '''
            SELECT GRIDOP.JOB_RDBD_INFO.JOB_ID,
                GRIDOP.JOB_RDBD_INFO.PRIM_RTE_DEFN_LN_ID AS RTE_DEFN_LN_ID,
                GRIDOP.JOB_RDBD_INFO.PRIM_RDBD_GL_ID AS RDBD_GMTRY_LN_ID,
                GRIDOP.JOB_RDBD_INFO.PRIM_RDBD_TYPE_ID AS RDBD_TYPE_ID,
                GRIDOP.JOB_RDBD_INFO.PRIM_RDBD_BEGMEASURE AS BEGIN_DFO,
                GRIDOP.JOB_RDBD_INFO.PRIM_RDBD_ENDMEASURE AS END_DFO,
                SDO_UTIL.TO_WKTGEOMETRY(GRIDOP.JOB_RDBD_INFO.PRIM_RDBD_SHAPE) AS SHAPE_LN
            FROM GRIDOP.JOB_RDBD_INFO
        '''
        update_sql = '''
            UPDATE JOB_RDBD_INFO
            SET RDBD_GMTRY_LN_ID=?,
                RDBD_TYPE_ID=?,
                BEGIN_DFO=?,
                END_DFO=?,
                SHAPE_LN=GeomFromText(?,4269)
            WHERE JOB_ID=? AND RTE_DEFN_LN_ID=?
        '''
        insert_sql = '''
            INSERT INTO JOB_RDBD_INFO
            SELECT ?,?,?,?,?,?,GeomFromText(?,4269)
            WHERE changes() = 0
        '''
        
        count = int(self.s_cursed.execute(table_exist).fetchone()[0])
        if count == 0:
            logging.info('Creating JOB_RDBD_INFO Table')
            for query in create_sql.split(';'):
                self.s_cursed.execute(query)
                
        logging.info('Upserting to JOB_RDBD_INFO')
        results = self.o_cursed.execute(select_sql)
        for row in results:
            row = (row[0],row[1],row[2],row[3],row[4],row[5],str(row[6]))
            self.s_cursed.execute(update_sql,(row[2],row[3],row[4],row[5],row[6],row[0], row[1]))
            self.s_cursed.execute(insert_sql, row)
            
    def task(self):
        table_exist = '''
            SELECT COUNT(*) FROM sqlite_master WHERE type = 'table' AND name = 'TASK'
        '''
        create_sql = '''
            CREATE TABLE TASK (
                TASK_ID INTEGER,
                JOB_ID INTEGER,
                SESSION_ID INTEGER,
                ITEM_ID INTEGER,
                PROCESS_TYPE VARCHAR(255),
                TASK_TYPE INTEGER,
                SKIPABLE INTEGER,
                CREATE_DT DATE,
                COMPLETE_DT DATE,
                PREV_STATUS INTEGER,
                TASK_STATUS VARCHAR(255),
                LOCK_STATUS INTEGER,
                INITIATOR_NM VARCHAR(255),
                OWNER_NM VARCHAR(255),
                CREATOR_NM VARCHAR(255),
                FOREIGN KEY (JOB_ID) REFERENCES JOB_INFO(JOB_ID) ON DELETE CASCADE
            );
            CREATE INDEX task_job_id on TASK(JOB_ID)
        '''
        select_sql = '''
            SELECT GRIDOP.TASK.ID           AS TASK_ID,
                GRIDOP.TASK.PROCESSINSTANCEID AS JOB_ID,
                GRIDOP.TASK.PROCESSSESSIONID  AS SESSION_ID,
                GRIDOP.TASK.WORKITEMID    AS ITEM_ID,
                GRIDOP.TASK.PROCESSID         AS PROCESS_TYPE,
                GRIDOP.TASK.PRIORITY          AS TASK_TYPE,
                GRIDOP.TASK.SKIPABLE,
                GRIDOP.TASK.CREATEDON         AS CREATE_DT,
                GRIDOP.TASK.COMPLETEDON       AS COMPLETE_DT,
                GRIDOP.TASK.PREVIOUSSTATUS    AS PREV_STATUS,
                GRIDOP.TASK.STATUS                AS TASK_STATUS,
                GRIDOP.TASK.OPTLOCK       AS LOCK_STATUS,
                GRIDOP.TASK.TASKINITIATOR AS INITIATOR_NM,
                GRIDOP.TASK.ACTUALOWNER   AS OWNER_NM,
                GRIDOP.TASK.CREATEDBY     AS CREATOR_NM
            FROM GRIDOP.TASK
            INNER JOIN GRIDOP.JOB_INFO
            ON GRIDOP.TASK.PROCESSINSTANCEID = GRIDOP.JOB_INFO.JOB_ID
        '''
        update_sql = '''
            UPDATE TASK
            SET COMPLETE_DT=?,
                PREV_STATUS=?,
                TASK_STATUS=?,
                LOCK_STATUS=?
            WHERE TASK_ID=?
        '''
        insert_sql = '''
            INSERT INTO TASK
            SELECT ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?
            WHERE changes() = 0
        '''
        
        count = int(self.s_cursed.execute(table_exist).fetchone()[0])
        if count == 0:
            logging.info('Creating TASK Table')
            for query in create_sql.split(';'):
                self.s_cursed.execute(query)
    
        logging.info('Upserting to TASK')
        results = self.o_cursed.execute(select_sql)
        for row in results:
            self.s_cursed.execute(update_sql, (row[8], row[9], row[10], row[11], row[0]))
            self.s_cursed.execute(insert_sql, row)
        
        logging.info('Marking Deleted Jobs')
        grid_list = []
        sqlite_list = []
        for row in self.o_cursed.execute('SELECT GRIDOP.TASK.ID FROM GRIDOP.TASK'):
            grid_list.append(row[0])
        for row in self.s_cursed.execute('''SELECT TASK.TASK_ID FROM TASK WHERE TASK.TASK_STATUS <> "Completed"'''):
            sqlite_list.append(row[0])
            
        for task_id in sqlite_list:
            if task_id not in grid_list:
                self.s_cursed.execute('''UPDATE TASK SET TASK_STATUS = 'Deleted' WHERE TASK_ID = ? ''', (task_id,))

                
def main(db_env, file_path = r'C:\_GRID_BACKUP', build_tables = True):
    '''
    This function will handle calls to other methods to build and fill databases
    will catch exceptions and handle database connections
    Args:
        db-env = GRID environment to be backed up
        file_path = path to job table backup folder
        build_tables = do we need to build the database (will make False if db exists)
    '''
    logpath = os.path.join(file_path, "job_tables_log")
    db_path = os.path.join(file_path,'job_tables_backup')
    
    if db_env.lower() in ['prod','pre','uat']:
        try:
            if not os.path.exists(logpath):
                os.makedirs(logpath)
            logfile = os.path.join(logpath, time.strftime("%m.%d.%Y_%H.%M") + "_log.txt")
            logging.basicConfig(filename=logfile,
                                level=logging.DEBUG,
                                filemode='w',
                                format='%(asctime)s - %(levelname)s: %(message)s',
                                datefmt='%m/%d/%Y %H:%M:%S ')
            logging.info("Begin Job Tables Backup Process\n")
                
            if not os.path.exists(db_path):
                os.makedirs(db_path)
            sqlite_db = os.path.join(db_path, r'job_tables_{0}.sqlite'.format(db_env))
            if os.path.exists(sqlite_db):
                build_tables = False
                
            logging.info('Creating Database Connections')
            s_con = connections.sqlite_con(sqlite_db)
            o_con = connections.grid_con(db_env)
            
            try:
                logging.info('Enabling SpatiaLite Extension\n')
                s_con.enable_load_extension(True)
                s_con.load_extension('mod_spatialite.dll')
            except sqlite3.Error as e:
                s_con.close()
                logging.error('Error loading SpatiaLite Extension, please ensure DLLs are properly installed and in the PATH')
                return
                
            s_cursed = s_con.cursor()
            o_cursed = o_con.cursor()
            
            if build_tables:
                try:
                    logging.info('Initializing Spatial Metadata\n')
                    s_cursed.execute('SELECT InitSpatialMetaData()')
                except sqlite3.Error as e:
                    logging.error('Error initializing Spatial Metadata: ' + str(e))
                    s_con.close()
                    os.remove(sqlite_db)
                    return
                    
            upsert = TableActions(o_cursed, s_cursed)
            
            #if any one of these fails, should reconnect to database, and re-run the process.  Add counter, so if they fail multiple times, will end operation with error message (if connection error) or skip operation for now (if data error).
            #wrap each part in a try clause, make sure to commit at specific points.  ETL_JOB_SCHED and JOB_INFO hold PRIMARY KEYS that are used in foreign key relationships. 
            #They must be committed before moving on.  If the other data gets lost, it can be recreated at a later date.  These two cannot be passed on, and must fail the operation without further commitment.

            upsert.etl_job_sched()
            upsert.etl_job_err()
            logging.info('Committing ETL data to the database\n')
            s_con.commit()
            
            upsert.job_info()
            upsert.job_data_pnt()
            upsert.job_data_ln()
            upsert.job_mod()
            upsert.job_rdbd_info()
            upsert.task()
            logging.info('Committing Job data to the database\n')
            s_con.commit()

            logging.info('Vacuuming the Database')
            s_con.execute('VACUUM')
            o_cursed.close()
            del o_cursed
            s_cursed.close()
            del s_cursed
                
            logging.info('Update of job_tables_{0} database successful'.format(db_env))
            return sqlite_db
        except (IOError, WindowsError, cx_Oracle.Error, sqlite3.Error) as e : 
            print('Error: '  + str(e))
            return
        finally:
            o_con.close()
            s_con.close()
    else:    
        print('Invalid GRID Environment; Please try again with pre, prod, or uat')
        return
    
if __name__ == '__main__':
    '''
    Using argparse to allow arguments to be run from the command line with the application
    When the module is run it will verify the arguments for the database environment.
    If no arguments are passed, it will query the user for an environment to run.
    '''
    parser = argparse.ArgumentParser()
    parser.add_argument('-e', '--env', action='store', choices=['prod', 'pre', 'uat', 'all'], type=str.lower)
    parser.add_argument('-l', '--loc', action='store')
    args = parser.parse_args()

    if args.env is None:
        args.env = raw_input('\nInsert GRID environment to back up (prod, pre, uat, or all): ').lower()
        if args.env not in ['prod','pre','uat','all']:
            print("\nInvalid argument choice: {0} (choose from prod, pre, uat, all)".format(args.env))
            sys.exit()
    if args.loc is None:
        args.loc = raw_input('\nInsert file location for GRID Backup: ')

    if args.env == 'all':
        main('prod',args.loc)
        main('pre',args.loc)
        main('uat',args.loc)
    else:
        main(args.env,args.loc)