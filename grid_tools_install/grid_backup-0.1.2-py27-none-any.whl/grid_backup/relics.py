#  The MIT License (MIT)
#
#  Copyright (c) 2015 Texas Department of Transportation
#  Author: David Hickman
#
#  Permission is hereby granted, free of charge, to any person obtaining a copy
#  of this software and associated documentation files (the "Software"), to deal
#  in the Software without restriction, including without limitation the rights
#  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#  copies of the Software, and to permit persons to whom the Software is
#  furnished to do so, subject to the following conditions:
#
#  The above copyright notice and this permission notice shall be included in
#  all copies or substantial portions of the Software.
#
#  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
#  THE SOFTWARE.

# imports
import os
import logging

from sqlalchemy import MetaData, Table

from sqlalchemy.exc import OperationalError
import arcpy

from arcpy import env

from connections import create_session, set_local_db_engine
from potions import *

def copy_rte_defn_ln_table():
    source_session = create_session()
    q = source_session.query(RteDefnLn.rte_defn_ln_id, RteDefnLn.rte_id, RteDefnLn.rdbd_gmtry_ln_id,
                             RteDefnLn.rte_defn_ln_nm, RteDefnLn.rte_defn_ln_begin_dfo_ms,
                             RteDefnLn.rte_defn_ln_end_dfo_ms)
    metadata = MetaData(bind=set_local_db_engine)
    columns = [Column(desc['name'], desc['type'])
               for desc in q.column_descriptions]
    column_names = [desc['name'] for desc in q.column_descriptions]
    table = Table('gridop.rte_defn_ln', metadata, *columns)

    try:
        table.drop(set_local_db_engine())

    except OperationalError as e:
        print e.message

    except Exception as e:
        print e.message

    table.create(set_local_db_engine())

    local_session = create_session('local')
    for row in q:
        local_session.execute(table.insert(row))
    local_session.commit()
    local_session.close()


def copy_rte_table():
    source_session = create_session()
    q = source_session.query(Rte.rte_id, Rte.rte_nbr, Rte.rte_prfx_type_id, RtePrfxType.rte_prfx_type_dscr,
                             Rte.rte_sfx_type_id, RteSfxType.rte_sfx_type_dscr, Rte.rte_eff_start_dt,
                             Rte.rte_eff_end_dt, Rte.cnty_type_nbr, RtePrfxType.rte_prfx_type_dscr)
    metadata = MetaData(bind=set_local_db_engine)
    columns = [Column(desc['name'], desc['type'])
               for desc in q.column_descriptions]
    column_names = [desc['name'] for desc in q.column_descriptions]
    table = Table('gridop.rte', metadata, *columns)

    try:
        table.drop(set_local_db_engine())

    except OperationalError as e:
        print e.message

    except Exception as e:
        print e.message

    table.create(set_local_db_engine())

    local_session = create_session('local')
    for row in q:
        local_session.execute(table.insert(row))
    local_session.commit()
    local_session.close()


def export_linear_asset(name, asset_type_id):
    source_session = create_session()
    q = source_session.query(AssetLn.asset_id, AssetLn.asset_ln_type_id, AssetLnType.asset_ln_type_dscr,
                             Asset.rdbd_gmtry_ln_id, AssetLn.asset_ln_begin_dfo_ms,
                             AssetLn.asset_ln_end_dfo_ms).filter(AssetLn.asset_ln_type_id == asset_type_id)
    metadata = MetaData(bind=set_local_db_engine)
    columns = [Column(desc['name'], desc['type'])
               for desc in q.column_descriptions]
    column_names = [desc['name'] for desc in q.column_descriptions]
    table = Table(name, metadata, *columns)

    try:
        table.drop(set_local_db_engine())

    except OperationalError as e:
        print e.message

    except Exception as e:
        print e.message

    table.create(set_local_db_engine())

    local_session = create_session('local')
    for row in q:
        local_session.execute(table.insert(row))
    local_session.commit()
    local_session.close()


def copy_county_domain_table():
    source_session = create_session()
    q = source_session.query(CountyType.cnty_type_nbr, CountyType.cnty_type_nm)
    metadata = MetaData(bind=set_local_db_engine)
    columns = [Column(desc['name'], desc['type'])
               for desc in q.column_descriptions]
    column_names = [desc['name'] for desc in q.column_descriptions]
    table = Table('gridop.cnty_type', metadata, *columns)

    try:
        table.drop(set_local_db_engine())

    except OperationalError as e:
        print e.message

    except Exception as e:
        print e.message

    table.create(set_local_db_engine())

    local_session = create_session('local')
    for row in q:
        local_session.execute(table.insert(row))
    local_session.commit()
    local_session.close()


def copy_rte_prefix_domain_table():
    source_session = create_session()
    q = source_session.query(RtePrfxType.rte_prfx_type_id,
                             RtePrfxType.rte_prfx_type_cd)
    metadata = MetaData(bind=set_local_db_engine)
    columns = [Column(desc['name'], desc['type'])
               for desc in q.column_descriptions]
    column_names = [desc['name'] for desc in q.column_descriptions]
    table = Table('gridop.rte_prfx_type', metadata, *columns)

    try:
        table.drop(set_local_db_engine())

    except OperationalError as e:
        print e.message

    except Exception as e:
        print e.message

    table.create(set_local_db_engine())

    local_session = create_session('local')
    for row in q:
        local_session.execute(table.insert(row))
    local_session.commit()
    local_session.close()


def copy_rte_suffix_domain_table():
    source_session = create_session()
    q = source_session.query(RteSfxType.rte_sfx_type_id,
                             RteSfxType.rte_sfx_type_dscr)
    metadata = MetaData(bind=set_local_db_engine)
    columns = [Column(desc['name'], desc['type'])
               for desc in q.column_descriptions]
    column_names = [desc['name'] for desc in q.column_descriptions]
    table = Table('gridop.rte_sfx_type', metadata, *columns)

    try:
        table.drop(set_local_db_engine())

    except OperationalError as e:
        print e.message

    except Exception as e:
        print e.message

    table.create(set_local_db_engine())

    local_session = create_session('local')
    for row in q:
        local_session.execute(table.insert(row))
    local_session.commit()
    local_session.close()


def copy_rdbd_domain_table():
    source_session = create_session()
    q = source_session.query(RdbdType.rdbd_type_id, RdbdType.rdbd_type_dscr)
    metadata = MetaData(bind=set_local_db_engine)
    columns = [Column(desc['name'], desc['type'])
               for desc in q.column_descriptions]
    column_names = [desc['name'] for desc in q.column_descriptions]
    table = Table('gridop.rdbd_type', metadata, *columns)

    try:
        table.drop(set_local_db_engine())

    except OperationalError as e:
        print e.message

    except Exception as e:
        print e.message

    table.create(set_local_db_engine())

    local_session = create_session('local')
    for row in q:
        local_session.execute(table.insert(row))
    local_session.commit()
    local_session.close()


def copy_st_prefix_domain_table():
    source_session = create_session()
    q = source_session.query(StPrfxType.st_prfx_type_id,
                             StPrfxType.st_prfx_type_cd, StPrfxType.st_prfx_type_dscr)
    metadata = MetaData(bind=set_local_db_engine)
    columns = [Column(desc['name'], desc['type'])
               for desc in q.column_descriptions]
    column_names = [desc['name'] for desc in q.column_descriptions]
    table = Table('gridop.st_prfx_type', metadata, *columns)

    try:
        table.drop(set_local_db_engine())

    except OperationalError as e:
        print e.message

    except Exception as e:
        print e.message

    table.create(set_local_db_engine())

    local_session = create_session('local')
    for row in q:
        local_session.execute(table.insert(row))
    local_session.commit()
    local_session.close()


def copy_st_domain_table():
    source_session = create_session()
    q = source_session.query(
        StType.st_type_id, StType.st_type_cd, StType.st_type_dscr)
    metadata = MetaData(bind=set_local_db_engine)
    columns = [Column(desc['name'], desc['type'])
               for desc in q.column_descriptions]
    column_names = [desc['name'] for desc in q.column_descriptions]
    table = Table('gridop.st_type', metadata, *columns)

    try:
        table.drop(set_local_db_engine())

    except OperationalError as e:
        print e.message

    except Exception as e:
        print e.message

    table.create(set_local_db_engine())

    local_session = create_session('local')
    for row in q:
        local_session.execute(table.insert(row))
    local_session.commit()
    local_session.close()


def copy_st_suffix_domain_table():
    source_session = create_session()
    q = source_session.query(StSfxType.st_sfx_type_id,
                             StSfxType.st_sfx_type_cd, StSfxType.st_sfx_type_dscr)
    metadata = MetaData(bind=set_local_db_engine)
    columns = [Column(desc['name'], desc['type'])
               for desc in q.column_descriptions]
    column_names = [desc['name'] for desc in q.column_descriptions]
    table = Table('gridop.st_sfx_type', metadata, *columns)

    try:
        table.drop(set_local_db_engine())

    except OperationalError as e:
        print e.message

    except Exception as e:
        print e.message

    table.create(set_local_db_engine())

    local_session = create_session('local')
    for row in q:
        local_session.execute(table.insert(row))
    local_session.commit()
    local_session.close()


def copy_cardinal_direction_domain_table():
    source_session = create_session()
    q = source_session.query(CrdnlDrctType.crdnl_drct_type_id, CrdnlDrctType.crdnl_drct_type_cd,
                             CrdnlDrctType.crdnl_drct_type_dscr)
    metadata = MetaData(bind=set_local_db_engine)
    columns = [Column(desc['name'], desc['type'])
               for desc in q.column_descriptions]
    column_names = [desc['name'] for desc in q.column_descriptions]
    table = Table('gridop.crdnl_drct_type', metadata, *columns)

    try:
        table.drop(set_local_db_engine())

    except OperationalError as e:
        print e.message

    except Exception as e:
        print e.message

    table.create(set_local_db_engine())

    local_session = create_session('local')
    for row in q:
        local_session.execute(table.insert(row))
    local_session.commit()
    local_session.close()


def copy_hpms_samples():
    source_session = create_session()
    q = source_session.query(HPMSSample.asset_id, AssetLn.asset_ln_begin_dfo_ms, AssetLn.asset_ln_end_dfo_ms,
                             HPMSSample.hpms_samp_nbr, HPMSSample.hpms_samp_begin_termnus_desc,
                             HPMSSample.hpms_samp_end_termnus_desc, HPMSSample.hpms_samp_ret_dt).filter(
        HPMSSample.asset_id == AssetLn.asset_id)
    metadata = MetaData(bind=set_local_db_engine)
    columns = [Column(desc['name'], desc['type'])
               for desc in q.column_descriptions]
    column_names = [desc['name'] for desc in q.column_descriptions]
    table = Table('gridop.hpms_samp', metadata, *columns)

    try:
        table.drop(set_local_db_engine())

    except OperationalError as e:
        print e.message

    except Exception as e:
        print e.message

    table.create(set_local_db_engine())

    local_session = create_session('local')
    for row in q:
        local_session.execute(table.insert(row))
    local_session.commit()
    local_session.close()


def copy_job_info_table():
    source_session = create_session()
    q = source_session.query(
        JobInfo.job_id,
        JobInfo.job_info_type,
        JobInfo.job_info_jl_flag,
        JobInfo.job_info_nm,
        JobInfo.job_info_dscr,
        JobInfo.job_info_cmnt,
        JobInfo.job_info_create_user_id,
        JobInfo.job_info_maintn_user_id,
        JobInfo.job_info_revw_user_id,
        JobInfo.job_info_rte_id,
        JobInfo.job_info_jl_beg_dfo,
        JobInfo.job_info_jl_end_dfo,
        JobInfo.job_info_jl_beg_lat,
        JobInfo.job_info_jl_beg_lon,
        JobInfo.job_info_jl_end_lat,
        JobInfo.job_info_jl_end_lon,
        JobInfo.job_info_ur_beg_dfo,
        JobInfo.job_info_ur_end_dfo,
        JobInfo.job_info_ur_beg_lat,
        JobInfo.job_info_ur_beg_lon,
        JobInfo.job_info_ur_end_lat,
        JobInfo.job_info_ur_end_lon,
        JobInfo.job_info_plans_url,
        JobInfo.job_info_plans_csj,
        JobInfo.job_info_district_id
    )
    metadata = MetaData(bind=set_local_db_engine)
    columns = [Column(desc['name'], desc['type'])
               for desc in q.column_descriptions]
    column_names = [desc['name'] for desc in q.column_descriptions]
    table = Table('gridop.job_info', metadata, *columns)

    try:
        table.drop(set_local_db_engine())

    except OperationalError as e:
        print e.message

    except Exception as e:
        print e.message

    table.create(set_local_db_engine())

    local_session = create_session('local')
    for row in q:
        local_session.execute(table.insert(row))
    local_session.commit()
    local_session.close()


def copy_rmrkr_pnt():
    source_session = create_session()
    q = source_session.query(
        ReferenceMarker.rmrkr_pnt_id,
        ReferenceMarker.rmrkr_pnt_nbr,
        ReferenceMarker.rmrkr_pnt_sfx_cd,
        ReferenceMarker.rdbd_gmtry_ln_id,
        ReferenceMarker.rdbd_type_id,
        ReferenceMarker.rmrkr_pnt_dt,
        ReferenceMarker.rmrkr_pnt_lat,
        ReferenceMarker.rmrkr_pnt_lon,
        ReferenceMarker.rmrkr_pnt_edit_dt,
        ReferenceMarker.rmrkr_pnt_edit_user_nm,
        ReferenceMarker.rmrkr_pnt_create_dt,
        ReferenceMarker.rmrkr_pnt_create_user_nm,
        ReferenceMarker.rmrkr_pnt_eff_start_dt,
        ReferenceMarker.rmrkr_pnt_eff_end_dt,
        ReferenceMarker.objectid,
        ReferenceMarker.rmrkr_updt_type_id,
        ReferenceMarker.rmrkr_pnt_dfo_ms,
        ReferenceMarker.stat_indctr
        )
    metadata = MetaData(bind=set_local_db_engine)
    columns = [Column(desc['name'], desc['type'])
               for desc in q.column_descriptions]
    column_names = [desc['name'] for desc in q.column_descriptions]
    table = Table('gridop.rmrkr_pnt', metadata, *columns)

    try:
        table.drop(set_local_db_engine())

    except OperationalError as e:
        print e.message

    except Exception as e:
        print e.message

    table.create(set_local_db_engine())

    local_session = create_session('local')
    for row in q:
        local_session.execute(table.insert(row))
    local_session.commit()
    local_session.close()


def replicate_grid_tables():
    # copy_st_prefix_domain_table()
    # copy_st_domain_table()
    # copy_st_suffix_domain_table()
    copy_hpms_samples()
