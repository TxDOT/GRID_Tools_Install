#  The MIT License (MIT)
#
#  Copyright (c) 2015 Texas Department of Transportation
#  Author: David Hickman
#
#  Permission is hereby granted, free of charge, to any person obtaining a copy
#  of this software and associated documentation files (the "Software"), to deal
#  in the Software without restriction, including without limitation the rights
#  to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#  copies of the Software, and to permit persons to whom the Software is
#  furnished to do so, subject to the following conditions:
#
#  The above copyright notice and this permission notice shall be included in
#  all copies or substantial portions of the Software.
#
#  THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#  IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#  FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#  AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#  LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#  OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
#  THE SOFTWARE.

# imports
from os import path
from time import localtime

from connections import set_grid_engine
from relics import *

def get_txdot_roadways_schema():
    """ Returns an array of TxDOT_Roadways fields """
    schema = dict()

    fields = [
        ('GID', 'LONG', 38, None, None, None),
        ('BEGIN_DFO', 'DOUBLE', 10, 3, None),
        ('END_DFO', 'DOUBLE', 10, 3, None),
        ('SEG_LEN', 'DOUBLE', 10, 3, None),
        ('RTE_RB_NM', 'TEXT', None, None, 17),
        ('RTE_GRID', 'LONG', 38, None, None),
        ('RTE_PRFX', 'SHORT', 2, None, None),
        ('RTE_NBR', 'TEXT', None, None, 10),
        ('RTE_SFX', 'SHORT', 2, None, None),
        ('RDBD_TYPE', 'SHORT', 2, None, None),
        ('DES_DRCT', 'SHORT', 2, None, None),
        ('RDBD_STAT', 'SHORT', 2, None, None),
        ('COUNTY', 'SHORT', 3, None, None),
        ('CREATE_DT', 'DATE', None, None, None),
        ('CREATE_NM', 'TEXT', None, None, 50),
        ('EDIT_DT', 'DATE', None, None, None),
        ('EDIT_NM', 'TEXT', None, None, 50),
        ('OGEOMS', 'TEXT', None, None, 100),
        ('EDIT_TYPE', 'TEXT', None, None, 20),
        ('ETL_JOB_ID', 'TEXT', None, None, 50),
        ('ETL_STAT', 'SHORT', 2, None, None)
    ]  # yapf: disable

    for i in range(1, len(fields) + 1):
        schema[i] = fields[i - 1]
    return schema

def get_tpp_editing_domains():
    """ Returns an array of Python dictionaries that define the domains associated with TxDOT_Roadways """
    tpp_domains = [
        {'name': "edit_type",
         'source_fields': None,
         'description': "GRID Edit Operations",
         'type': "TEXT",
         'target_field': "EDIT_TYPE",
         'order_by_field': None,
         'values': [('Add Roadbed', 'Add Roadbed'),
                    ('Retire Roadbed', 'Retire Roadbed'),
                    ('Add Route', 'Add Route'),
                    ('Retire Route', 'Retire Route')]},
        {'name': "etl_stat",
         'source_fields': None,
         'description': "GRID Edit Status",
         'type': "SHORT",
         'target_field': "ETL_STAT",
         'order_by_field': None,
         'values': [(1, 'Hold'),
                    (2, 'Ready'),
                    (3, 'Error')]},
        {'name': "rdbd_stat", 'source_fields': None,
         'description': "Roadbed Status",
         'type': "SHORT",
         'target_field': "RDBD_STAT",
         'order_by_field': None,
         'values': [(1, 'Closed To Traffic'),
                    (2, 'Open To Traffic')]}
    ]  # yapf: disable

    return tpp_domains


def get_grid_domains():
    grid_domains = [
        {'name': "cnty_type",
         'source_fields': ["cnty_type_nbr", "cnty_type_nm"],
         'description': "County Domain",
         'type': "TEXT",
         'target_field': "COUNTY",
         'order_by_field': "cnty_type_nm",
         'values': None},
        {'name': "rte_prfx_type",
         'source_fields': ["rte_prfx_type_id", "rte_prfx_type_cd"],
         'description': "Route Prefix Domain",
         'type': "SHORT",
         'target_field': "RTE_PRFX",
         'order_by_field': "rte_prfx_type_cd",
         'values': None},
        {'name': "rte_sfx_type",
         'source_fields': ["rte_sfx_type_id", "rte_sfx_type_dscr"],
         'description': "Route Suffix Domain",
         'type': "SHORT",
         'target_field': "RTE_SFX",
         'order_by_field': None,
         'values': None},
        {'name': "rdbd_type",
         'source_fields': ["rdbd_type_id", "rdbd_type_dscr"],
         'description': "Roadbed Type Domain",
         'type': "SHORT",
         'target_field': "RDBD_TYPE",
         'order_by_field': None,
         'values': None},
        {'name': "crdnl_drct_type",
         'source_fields': ["crdnl_drct_type_id", "crdnl_drct_type_dscr"],
         'description': "Cardinal Direction Type Domain",
         'type': "SHORT",
         'target_field': "DES_DRCT",
         'order_by_field': None,
         'values': None}
    ] + get_tpp_editing_domains()   # yapf: disable

    return grid_domains


def create_txdot_roadways_schema(target_fc, time_string, sde=False):
    """
    Main function to create the output feature class/dataset and domain tables and populate the domain tables with
    values
    """
    # logging support
    logpath = "D:\\_GRID_BACKUP\\sde_export_logs"
    logfile = path.join(logpath, "grid_roadway_export_log.txt")
    if not os.path.exists(logpath):
        os.makedirs(logpath)
    logging.basicConfig(filename=logfile,
                        level=logging.DEBUG,
                        filemode='a',
                        format='%(asctime)s - %(levelname)s: %(message)s',
                        datefmt='%m/%d/%Y %I:%M:%S %p')

    feature_dataset_path = path.dirname(target_fc)
    gdb_path = path.dirname(feature_dataset_path)

    # ArcGIS Environment Settings
    env.MResolution = 0.001
    env.MTolerance = 0.002

    if sde:
        env.workspace = feature_dataset_path
        domain_list = [str(d.name) for d in arcpy.da.ListDomains(gdb_path)]
    else:
        env.workspace = gdb_path

    # Setup functions
    copy_rte_prefix_domain_table()
    copy_rte_suffix_domain_table()
    copy_rdbd_domain_table()
    copy_county_domain_table()
    copy_cardinal_direction_domain_table()

    if not sde:
        if arcpy.Exists(gdb_path):
            if arcpy.Exists(target_fc):
                arcpy.Delete_management(target_fc)
            arcpy.Delete_management(gdb_path)

    sr = arcpy.SpatialReference(3081)

    if not sde:
        arcpy.CreateFileGDB_management(path.dirname(gdb_path), path.basename(gdb_path))

    arcpy.CreateFeatureDataset_management(gdb_path, path.basename(feature_dataset_path), spatial_reference=sr)

    arcpy.CreateFeatureclass_management(feature_dataset_path,
                                        path.basename(target_fc),
                                        geometry_type='POLYLINE',
                                        has_m='ENABLED',
                                        spatial_reference=arcpy.SpatialReference(3081))

    schema = get_txdot_roadways_schema()

    logging.info("...Adding Fields")
    for f in sorted(schema.keys()):
        arcpy.AddField_management(target_fc,
                                  field_name=schema[f][0],
                                  field_type=schema[f][1],
                                  field_precision=schema[f][2],
                                  field_scale=schema[f][3],
                                  field_length=schema[f][4])

    target_fc_fields = [f.name for f in arcpy.ListFields(target_fc)]

    local_session = create_session(source='local')

    domains = get_grid_domains()

    logging.info("...Copying domains")
    for d in domains:

        domain_name = d['name']

        if sde:
            if domain_name in domain_list:
                logging.info('Deleting domain {0}'.format(domain_name))
                arcpy.DeleteDomain_management(gdb_path, domain_name)

        logging.info('Creating new domain {0}'.format(domain_name))
        arcpy.CreateDomain_management(gdb_path, domain_name, d['description'], d['type'])

        if d['target_field'] in target_fc_fields:
            arcpy.AssignDomainToField_management(target_fc, d['target_field'], domain_name)

        else:
            logging.error("{0} field not found in target table!".format(d['target_field']))
            pass

        if not d['source_fields']:
            result = d['values']

        else:

            if d['order_by_field']:
                sql_statement = 'SELECT "{0}", "{1}" FROM "gridop.{2}" ORDER BY "{3}" ASC'.format(
                    d['source_fields'][0], d['source_fields'][1], d['name'], d['order_by_field'])
            else:
                sql_statement = 'SELECT "{0}", "{1}" FROM "gridop.{2}"'.format(d['source_fields'][0],
                                                                               d['source_fields'][1], d['name'])

            result = local_session.execute(sql_statement).fetchall()

        for row in result:

            if d['name'] == "rdbd_type" and str(row[0]).strip() == '4':
                continue

            elif d['type'] == "TEXT":
                value = str(row[0])
                desc = str(row[1])

            else:
                value = int(row[0])
                desc = str(row[1])

            arcpy.AddCodedValueToDomain_management(gdb_path, domain_name, value, desc)


def copy_grid_roadways(sde=False):
    """ Make a copy of GRID Roadways on SDE """
    logpath = "D:\\_GRID_BACKUP\\sde_export_logs"
    logfile = path.join(logpath, "grid_roadway_export_log.txt")
    if not os.path.exists(logpath):
        os.makedirs(logpath)
    logging.basicConfig(filename=logfile,
                        level=logging.DEBUG,
                        filemode='a',
                        format='%(asctime)s - %(levelname)s: %(message)s',
                        datefmt='%m/%d/%Y %I:%M:%S %p')

    start_time = localtime()

    logging.info("\n")
    logging.info("Start Time: {0}".format(start_time))

    time_string = "{0}_{1}_{2}_{3}_{4}_{5}".format(start_time.tm_mon, start_time.tm_mday, start_time.tm_year,
                                                   start_time.tm_hour, start_time.tm_min, start_time.tm_sec)
    dataset = "GRID_Roadways"
    fc = "TxDOT_Roadways"
    if sde:
        sde = "Database Connections\\Connection to Cherokee.sde"
        target_fc = path.join(sde, dataset, fc)

    else:
        output_gdb = "D:\\_GRID_BACKUP\\GRID_Roadways_{0}.gdb".format(time_string)
        target_fc = path.join(output_gdb, dataset, fc)

    create_txdot_roadways_schema(target_fc, time_string)

    def format_integer(v):
        """format an integer value"""
        try:
            return int(v)
        except TypeError:
            return None

    def get_m(p, position):

        if position == 'first':
            try:
                return p.firstPoint.M
            except SystemError as e:
                logging.error("Error retrieving measure value! -\n{0}: {1}".format(e.errno, e.strerror))
                return None
        elif position == 'last':
            try:
                return p.lastPoint.M
            except SystemError as e:
                logging.error("Error retrieving measure value! -\n{0}: {1}".format(e.errno, e.strerror))
                return None
        else:
            # print "Null measure value!"
            logging.error("Null measure value!")
            return None

    def geom_row_prep(arr, previous_row):
        polyline = arcpy.Polyline(arr, arcpy.SpatialReference(4269), "False", "True")
        polyline_proj = polyline.projectAs(arcpy.SpatialReference(3081))
        write_row = [previous_row[0], polyline_proj, get_m(polyline_proj, 'first'), get_m(polyline_proj, 'last'),
                     polyline_proj.getLength(units="MILES"), str(previous_row[4]), int(previous_row[5]),
                     int(previous_row[6]), str(previous_row[7]), format_integer(previous_row[8]), int(previous_row[9]),
                     int(previous_row[10]), format_integer(previous_row[11])]
        return write_row

    def copy_rdbd_gmtry_ln():

        arcpy.env.outputMFlag = "Enabled"

        sql_statement = """SELECT
                            g.RDBD_GMTRY_LN_ID,
                            g.x,
                            g.y,
                            g.z,
                            rdl.RTE_DEFN_LN_NM,
                            rdl.RTE_ID,
                            rt.RTE_PRFX_TYPE_ID,
                            rt.RTE_NBR,
                            rt.RTE_SFX_TYPE_ID,
                            rdl.RDBD_TYPE_ID,
                            rdl.CRDNL_DRCT_TYPE_ID,
                            rt.CNTY_TYPE_NBR
                            FROM GRIDOP.RDBD_GMTRY_LN rgl
                            INNER JOIN
                            (
                                SELECT
                                rgl.RDBD_GMTRY_LN_ID, t.x, t.y, t.z
                                FROM GRIDOP.RDBD_GMTRY_LN rgl, TABLE(sdo_util.getvertices(rgl.shape)) t
                            ) g
                            ON g.RDBD_GMTRY_LN_ID = rgl.RDBD_GMTRY_LN_ID
                            INNER JOIN GRIDOP.RTE_DEFN_LN rdl ON rdl.RDBD_GMTRY_LN_ID = rgl.RDBD_GMTRY_LN_ID
                            INNER JOIN GRIDOP.RTE rt ON rt.RTE_ID = rdl.RTE_ID
                            WHERE rdl.RTE_DEFN_LN_PRMRY_FLAG = 1"""
                            #AND rgl.RDBD_GMTRY_LN_ID = 1

        engine = set_grid_engine()
        result = engine.execute(sql_statement)

        geom_rows = arcpy.da.InsertCursor(target_fc,
                                          ["GID", "SHAPE@", "BEGIN_DFO", "END_DFO", "SEG_LEN", "RTE_RB_NM", "RTE_GRID",
                                           "RTE_PRFX", "RTE_NBR", "RTE_SFX", "RDBD_TYPE", "DES_DRCT", "COUNTY"])

        # Set placeholder variables
        a = arcpy.Array()
        previous_gid = None
        previous_row = None
        record_counter = 0

        for row in result:

            if row[0] == previous_gid or previous_gid is None:
                # Add point to existing array
                p = arcpy.Point(X=float(row[1]), Y=float(row[2]), M=float(row[3]))
                a.append(p)

            else:
                # Create a row and write it to the output feature class
                write_row = geom_row_prep(a, previous_row)
                geom_rows.insertRow(write_row)
                record_counter += 1

                # Start a new geometry object
                a = arcpy.Array()
                p = arcpy.Point(X=float(row[1]), Y=float(row[2]), M=float(row[3]))
                a.append(p)

            # Store the previous row info for later use
            previous_row = row
            previous_gid = row[0]

        # Clean up the final record
        write_row = geom_row_prep(a, previous_row)
        geom_rows.insertRow(write_row)
        record_counter += 1

    copy_rdbd_gmtry_ln()

    end_time = localtime()

    logging.info("\n")
    logging.info("End Time: {0}\n".format(end_time))


if __name__ == '__main__':
    copy_grid_roadways()
