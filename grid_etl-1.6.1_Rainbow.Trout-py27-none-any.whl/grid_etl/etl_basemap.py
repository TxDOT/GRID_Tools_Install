"""
The MIT License (MIT)

Copyright (c) 2014 Texas Department of Transportation

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

"""


def etl(job_limit=None, layer_limit=None, debug=False):

    import gdal_env
    import subprocess
    import os
    import time
    import shutil
    import logging
    from datetime import datetime

    import arcpy
    from arcpy import env
    import yaml

    from etl_config import config

    startTime = datetime.now()
    beg_time = time.ctime()

    start_time = time.localtime()
    time_string = "{0}_{1}_{2}_{3}_{4}_{5}".format(start_time.tm_mon, start_time.tm_mday, start_time.tm_year,
                                                   start_time.tm_hour, start_time.tm_min, start_time.tm_sec)

    current_directory = os.path.dirname(os.path.realpath(__file__))

    config_file = os.path.join(current_directory, 'etl_config_resources\\etl_config_paths.yml')

    if not os.path.exists(config_file):
        config()
        print "\nContinuing with grid_etl."

    # Open and read configuration file
    with open(config_file, 'r') as ymlfile:
        cfg = yaml.load(ymlfile)

    log_directory = os.path.join(cfg["paths"]["output_location"], 'etl_basemap_logs')

    if not os.path.exists(log_directory):
        os.makedirs(log_directory)

    log_file = os.path.join(log_directory, "EtlBasemapLog_" + time_string + ".log")

    logging.basicConfig(filename=log_file, level=logging.DEBUG)

    # Configuration logging info
    logging.info("\n\n")
    logging.info("***********************************************************")
    logging.info("Began: " + beg_time)
    logging.info("\n")
    logging.info("Configuration file loaded...")
    logging.info("Basemap Geodatabase: " + cfg["paths"]["basemap_geodatabase"])
    logging.info("Output Location: " + cfg["paths"]["output_location"])
    logging.info("***********************************************************")
    logging.info("\n\n")

    session_dictionary = {}

    def create_gml(job_num, input_features_path, java_name, grid_name, output_path):
        """
        Create the ETL output package for GRID
        :param
        input_name: The name of the feature type. (Ex: RoadbedGeometryLine)
        input_features: The input geometry (Currently route_defn_ln_xml_obj shapefile)
        output_path: The directory path to output the GML files
        """
        output_file = os.path.join(output_path, java_name + '-job{0}.gml'.format(job_num))

        # Define ogr2ogr command
        ogr_command = 'ogr2ogr -f "GML" -dsco FORMAT=GML3 ' \
                      ' -s_srs "+proj=latlong +datum=NAD83'\
                      ' +axis=enu +wktext" ' \
                      ' -t_srs "+proj=latlong +datum=NAD83'\
                      ' +axis=neu +wktext" ' \
                      ' -nln {0} {1} {2} -sql "SELECT * FROM ' \
                      ' {3}"'.format(java_name,
                                     output_file,
                                     input_features_path,
                                     grid_name + '_changes_job' + str(job_num))

        # Create the ogr2ogr process
        process = subprocess.Popen(ogr_command, stdout=subprocess.PIPE, creationflags=0x08000000)

        # Execute ogr2ogr process when available
        process.wait()

        logging.info("FILE CREATED: {0}".format(output_file))
        logging.info("OGR_COMMAND: {0}".format(ogr_command))

    def cleanup_directory(folder_path):
        for xsd_file in os.listdir(os.path.dirname(folder_path)):
            if xsd_file.endswith(".xsd"):
                os.remove(os.path.join(os.path.dirname(folder_path), xsd_file))

        shutil.rmtree(folder_path)

    def create_basemap_etl(filegdb, job_limit, layer_limit, local_gdb):

        if not local_gdb:
            basemap_dictionary = {
                'TPP_GIS.APP_TPP_GIS_ADMIN.ADJ_STATE_POLY': 'AdjoiningStatePoly',
                'TPP_GIS.APP_TPP_GIS_ADMIN.AIRPORT_PNT': 'AirportPoint',
                'TPP_GIS.APP_TPP_GIS_ADMIN.AIRPORT_POLY': 'AirportBoundaryPoly',
                'TPP_GIS.APP_TPP_GIS_ADMIN.AIRPORT_RUNWAYS_POLY': 'AirportRunwayPoly',
                'TPP_GIS.APP_TPP_GIS_ADMIN.CEMETERY_PNT': 'CemeteryPoint',
                'TPP_GIS.APP_TPP_GIS_ADMIN.CEMETERY_POLY': 'CemeteryBoundaryPoly',
                'TPP_GIS.APP_TPP_GIS_ADMIN.CITY_DTL_POLY': 'CityDetailPoly',
                'TPP_GIS.APP_TPP_GIS_ADMIN.CITY_PNT': 'CityPoint',
                'TPP_GIS.APP_TPP_GIS_ADMIN.EDUCATION_POLY': 'EducationBoundaryPoly',
                'TPP_GIS.APP_TPP_GIS_ADMIN.GRID_BUFFER': 'GridBuffer',
                'TPP_GIS.APP_TPP_GIS_ADMIN.LAKE_POLY': 'LakePoly',
                'TPP_GIS.APP_TPP_GIS_ADMIN.MILIT_LAND_POLY': 'MilitaryLandBoundaryPoly',
                'TPP_GIS.APP_TPP_GIS_ADMIN.MPO_POLY': 'MpoBoundaryPoly',
                'TPP_GIS.APP_TPP_GIS_ADMIN.MSA_POLY': 'MsaBoundaryPoly',
                'TPP_GIS.APP_TPP_GIS_ADMIN.PBLC_LAND_POLY': 'PublicLandPoly',
                'TPP_GIS.APP_TPP_GIS_ADMIN.PRISON_POLY': 'PrisonBoundaryPoly',
                'TPP_GIS.APP_TPP_GIS_ADMIN.RAIL_RD_LN': 'RailroadLine',
                'TPP_GIS.APP_TPP_GIS_ADMIN.STRM_DTL_LN': 'StreamDetailLine',
                'TPP_GIS.APP_TPP_GIS_ADMIN.TXDOT_CNTY_LN': 'TxdotCountyBoundaryLine',
                'TPP_GIS.APP_TPP_GIS_ADMIN.TXDOT_CNTY_POLY': 'TxdotCountyBoundaryPoly',
                'TPP_GIS.APP_TPP_GIS_ADMIN.TXDOT_CNTY_DETAIL_POLY': 'TxdotCountyDetailBoundaryPoly',
                'TPP_GIS.APP_TPP_GIS_ADMIN.TXDOT_DIST_LN': 'TxdotDistrictBoundaryLine',
                'TPP_GIS.APP_TPP_GIS_ADMIN.TXDOT_DIST_POLY': 'TxdotDistrictBoundaryPoly',
                'TPP_GIS.APP_TPP_GIS_ADMIN.TXDOT_OFFICE_MAINT_POLY': 'TxdotMaintSectionPoly',
                'TPP_GIS.APP_TPP_GIS_ADMIN.TXDOT_REGN_POLY': 'TxdotRegionBoundaryPoly',
                'TPP_GIS.APP_TPP_GIS_ADMIN.UZA_POLY': 'UrbanAreaPoly'
            }

        else:
            basemap_dictionary = {
                'ADJ_STATE_POLY': 'AdjoiningStatePoly',
                'AIRPORT_PNT': 'AirportPoint',
                'AIRPORT_POLY': 'AirportBoundaryPoly',
                'AIRPORT_RUNWAYS_POLY': 'AirportRunwayPoly',
                'CEMETERY_PNT': 'CemeteryPoint',
                'CEMETERY_POLY': 'CemeteryBoundaryPoly',
                'CITY_DTL_POLY': 'CityDetailPoly',
                'CITY_PNT': 'CityPoint',
                'EDUCATION_POLY': 'EducationBoundaryPoly',
                'GRID_BUFFER': 'GridBuffer',
                'LAKE_POLY': 'LakePoly',
                'MILIT_LAND_POLY': 'MilitaryLandBoundaryPoly',
                'MPO_POLY': 'MpoBoundaryPoly',
                'MSA_POLY': 'MsaBoundaryPoly',
                'PBLC_LAND_POLY': 'PublicLandPoly',
                'PRISON_POLY': 'PrisonBoundaryPoly',
                'RAIL_RD_LN': 'RailroadLine',
                'STRM_DTL_LN': 'StreamDetailLine',
                'TXDOT_CNTY_LN': 'TxdotCountyBoundaryLine',
                'TXDOT_CNTY_POLY': 'TxdotCountyBoundaryPoly',
                'TXDOT_CNTY_DETAIL_POLY': 'TxdotCountyDetailBoundaryPoly',
                'TXDOT_DIST_LN': 'TxdotDistrictBoundaryLine',
                'TXDOT_DIST_POLY': 'TxdotDistrictBoundaryPoly',
                'TXDOT_OFFICE_MAINT_POLY': 'TxdotMaintSectionPoly',
                'TXDOT_REGN_POLY': 'TxdotRegionBoundaryPoly',
                'UZA_POLY': 'UrbanAreaPoly'
            }

        env.workspace = filegdb
        env.overwriteOutput = True

        basemap_layers = arcpy.ListFeatureClasses()

        for lyr in basemap_layers:

            if not local_gdb:
                lyr_name = lyr.split(".")[-1]
            else:
                lyr_name = lyr

            if not layer_limit or lyr_name in layer_limit:

                change_query = """ "GRID_OP" = 'Add' OR "GRID_OP" = 'Replace' OR "GRID_OP" = 'Delete'"""

                arcpy.MakeFeatureLayer_management(lyr, 'in_memory\\' + lyr + '_changes', change_query)

                count_result = arcpy.GetCount_management('in_memory\\' + lyr + '_changes')

                count = int(count_result.getOutput(0))

                logging.info('\n')
                logging.info('\nBasemap Feature Class: {0}'.format(lyr))
                logging.info('...{0} feature edits found'.format(count))

                if count > 0:

                    jobs_list = []

                    job_search_rows = arcpy.SearchCursor('in_memory\\' + lyr + '_changes')

                    for row in job_search_rows:
                        if row.ETL_TEST_ID not in jobs_list:
                            jobs_list.append(row.ETL_TEST_ID)

                    for job in jobs_list:

                        if not job_limit or job in job_limit:

                            job_query = """ "ETL_TEST_ID" = {0}""".format(job)

                            run_output_directory = os.path.join(cfg["paths"]["output_location"],
                                                                'etl_basemap_' + time_string + '_job' + str(job))

                            if not os.path.exists(run_output_directory):
                                os.mkdir(run_output_directory)

                            fgdb_name = 'etl_basemap_' + 'job' + str(job) + '.gdb'
                            fgdb_output = os.path.join(run_output_directory, fgdb_name)

                            if not os.path.exists(fgdb_output):
                                arcpy.CreateFileGDB_management(run_output_directory, fgdb_name, "CURRENT")

                            arcpy.FeatureClassToFeatureClass_conversion('in_memory\\' + lyr + '_changes', fgdb_output,
                                                                        (lyr_name + '_changes_job' + str(job)),
                                                                        job_query)

                            create_gml(job, fgdb_output, basemap_dictionary[lyr], lyr_name, run_output_directory)

                            # Edit made to add basement job report to ETL page
                            session_dictionary[str(job)] = {'job_type': 'Roadway', 'status': True}

                            if debug is False and fgdb_output is not None:
                                cleanup_directory(fgdb_output)

    if os.path.splitext(cfg["paths"]["basemap_geodatabase"])[1].lower() == '.gdb':
        local_gdb = True
    else:
        local_gdb = False

    create_basemap_etl(cfg["paths"]["basemap_geodatabase"], job_limit, layer_limit, local_gdb)

    end_time = time.ctime()
    logging.info("Complete: " + end_time)
    end_date_time = datetime.now()
    run_time = (end_date_time - startTime)
    logging.info("Total Run Time: " + str(run_time))
