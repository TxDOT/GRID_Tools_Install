"""
USER NAME: DAVID HICKMAN
FILE NAME: etl_tests.py

The MIT License (MIT)

Copyright (c) 2014 Texas Department of Transportation

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

"""

# imports
import pytest
from os import path

import arcpy

from etl_util import return_truncated_coord, get_first_x, get_first_y, get_first_m, get_last_y, get_last_x, \
    cleanup_directory


class TestHelpers:
    @pytest.fixture(scope='module')
    def truncated_coord(self):
        """
        Returns a
        :return:
        """
        return return_truncated_coord('32.123456789')

    @pytest.fixture(scope='module')
    def sample_geom(self):
        array = arcpy.Array()
        p1 = arcpy.Point(X=float(-97.123456789), Y=float(32.123456789), M=float(0.0001))
        p2 = arcpy.Point(X=float(-97.987654321), Y=float(32.987654321), M=float(100.000))
        array.append(p1)
        array.append(p2)
        polyline = arcpy.Polyline(array)
        return polyline

    def test_return_truncated_coord_string(self):
        c = self.truncated_coord()
        assert isinstance(c, str)

    def test_return_truncated_coord_precision(self):
        c = self.truncated_coord()
        assert len(c.split(".")[1]) == 8

    def test_get_first_coord(self):
        g = self.sample_geom()
        assert get_first_x(g) == str(-97.12345678)    # verifies the precision, type, and value of coord.
        assert get_first_y(g) == str(32.12345678)

    def test_get_last_coord(self):
        g = self.sample_geom()
        assert get_last_x(g) == str(-97.98765432)
        assert get_last_y(g) == str(32.98765432)

    def test_cleanup_directory(self, tmpdir):
        d = str(tmpdir.mkdir("test").join("test_file.txt"))
        cleanup_directory(path.dirname(d))
        assert not path.exists(d)
