"""
The MIT License (MIT)

Copyright (c) 2014 Texas Department of Transportation

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

"""

import os
from os import path
from os import remove

import yaml
from grid_etl.etl_database import apothecary


def config_direct(config_dict, retain_packet_database=True):
    """
    Sets configuration for the grid_etl script.
    :param config_dict: dictionary containing the path values for configuring the etl_packet tool
    :param retain_packet_database: boolean to keep or delete the packet dictionary
    :return: None
    """

    current_directory = path.dirname(path.realpath(__file__))
    config_file = path.join(current_directory, 'etl_config_resources\\etl_config_paths.yml')

    config_data = {'paths': {
        'features': '{0}'.format(path.normpath(config_dict["features"])),
        'basemap_geodatabase': '{0}'.format(path.normpath(config_dict["basemap geodatabase"])),
        'output_location': '{0}'.format(path.normpath(config_dict["output location"]))
    }}

    with open(config_file, 'w') as ymlfile:
        ymlfile.write(yaml.dump(config_data, default_flow_style=False))

    # Check for database
    current_directory = path.dirname(path.realpath(__file__))
    db_file = path.join(current_directory, 'etl_database\\etl_packets.db')

    if not path.exists(db_file):
        apothecary.create_tables()
    else:
        if not retain_packet_database:
            remove(db_file)
            apothecary.create_tables()


def show_direct():

    current_directory = path.dirname(path.realpath(__file__))
    config_file = path.join(current_directory, 'etl_config_resources\\etl_config_paths.yml')

    if not os.path.exists(config_file):
        return False

    with open(config_file, 'r') as ymlfile:
        cfg = yaml.load(ymlfile)

        config_dict = dict()

        config_dict['features'] = cfg["paths"]["features"]
        config_dict['basemap geodatabase'] = cfg["paths"]["basemap_geodatabase"]
        config_dict['output location'] = cfg["paths"]["output_location"]

    return config_dict


def config(features_path=None, basemap_geodatabase_path=None, output_location_path=None):
    """
    Set the configuration variables for the ETL run environment

    :param features_path: path for feature linework
    :param basemap_geodatabase_path: path to geodatabase containing basemap features
    :param output_location_path: output folder location
    :return: None
    """

    current_directory = path.dirname(path.realpath(__file__))
    config_file = path.join(current_directory, 'etl_config_resources\\etl_config_paths.yml')

    def _check_for_path(path_key):

        with open(config_file, 'r') as ymlfile:
            cfg = yaml.load(ymlfile)

        if "paths" in cfg.keys():
            if path_key in cfg["paths"].keys():
                return cfg["paths"][path_key]
        else:
            return False

    def _get_new_path(path_key):

        if path_key == "features":
            features = raw_input("Enter the path to your linework: \n")
            return path.normpath(features)

        elif path_key == "basemap_geodatabase":
            basemap_geodatabase = raw_input("Enter the path to your basemap geodatabase: \n")
            return path.normpath(basemap_geodatabase)

        elif path_key == "output_location":
            output_location = raw_input("Enter the desired output directory: \n")
            return path.normpath(output_location)

    print "\n================================================================="

    print "Set up your desired configuration"
    print "=================================================================\n"

    affirmative = ['Y', 'Yes', 'y', 'yes', '']

    # Check for existing features config file
    if path.exists(config_file):
        for element in ["features", "basemap_geodatabase", "output_location"]:

            # Check if element already has an entry in the config file
            if not _check_for_path(element):
                # If no entry exists in the config file set the path based on the function params or ask the user for
                # a path.
                if element == "features":
                    if features_path:
                        features = path.normpath(features_path)
                    else:
                        features = _get_new_path(element)

                elif element == "basemap_geodatabase":
                    if basemap_geodatabase_path:
                        basemap_geodatabase = path.normpath(basemap_geodatabase_path)
                    else:
                        basemap_geodatabase = _get_new_path(element)

                elif element == "output_location":
                    if output_location_path:
                        output_location = path.normpath(output_location_path)
                    else:
                        output_location = _get_new_path(element)
            else:
                ask_update = raw_input("Keep current path for {0}? (y/n): {1}\n".format(element, _check_for_path(
                    element)))

                if ask_update in affirmative:
                    if element == "features":
                        features = _check_for_path(element)

                    elif element == "basemap_geodatabase":
                        basemap_geodatabase = _check_for_path(element)

                    elif element == "output_location":
                        output_location = _check_for_path(element)

                else:
                    if element == "features":
                        features = _get_new_path(element)

                    elif element == "basemap_geodatabase":
                        basemap_geodatabase = _get_new_path(element)

                    elif element == "output_location":
                        output_location = _get_new_path(element)

    else:
        for element in ["features", "basemap_geodatabase", "output_location"]:
            if element == "features":
                if features_path:
                    features = path.normpath(features_path)
                else:
                    features = _get_new_path(element)

            elif element == "basemap_geodatabase":
                if basemap_geodatabase_path:
                    basemap_geodatabase = path.normpath(basemap_geodatabase_path)
                else:
                    basemap_geodatabase = _get_new_path(element)

            elif element == "output_location":
                if output_location_path:
                    output_location = path.normpath(output_location_path)
                else:
                    output_location = _get_new_path(element)

    config_data = {'paths': {
        'features': '{0}'.format(features),
        'basemap_geodatabase': '{0}'.format(basemap_geodatabase),
        'output_location': '{0}'.format(output_location)
    }}

    with open(config_file, 'w') as ymlfile:
        ymlfile.write(yaml.dump(config_data, default_flow_style=False))

    # Check for database
    current_directory = path.dirname(path.realpath(__file__))
    db_file = path.join(current_directory, 'etl_database\\etl_packets.db')

    if not path.exists(db_file):
        apothecary.create_tables()
    else:
        ask_update = raw_input("Keep current packet database? (y/n): \n")
        if ask_update in affirmative:
            pass
        else:
            remove(db_file)
            apothecary.create_tables()
    print "\n================================================================="
    print "Configuration Successful!"
    print "=================================================================\n"


def show():

    current_directory = path.dirname(path.realpath(__file__))
    config_file = path.join(current_directory, 'etl_config_resources\\etl_config_paths.yml')

    if not os.path.exists(config_file):
        print "\nNo configuration file found."
        print "\nPlease create one using the config function."
        return 0

    print "================================================================="

    print "Current configuration"
    print "=================================================================\n"

    affirmative = ['Y', 'Yes', 'y', 'yes', '']

    with open(config_file, 'r') as ymlfile:
        cfg = yaml.load(ymlfile)

    print "Linework: {0}\n".format(cfg["paths"]["features"])
    print "Basemap Geodatabase: {0}\n".format(cfg["paths"]["basemap_geodatabase"])
    print "Output Location: {0}\n".format(cfg["paths"]["output_location"])

    ask_update = raw_input("Would you like to update?: (y/n) \n")

    if ask_update in affirmative:
        config()
    else:
        print "Configuration unchanged"
    print "================================================================="
