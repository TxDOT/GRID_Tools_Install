"""
The MIT License (MIT)

Copyright (c) 2014 Texas Department of Transportation

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
THE SOFTWARE.

"""
from os import path, listdir
from zipfile import ZipFile, ZIP_DEFLATED
from xml.etree.ElementTree import ElementTree
from lxml import etree
import shutil


def include_file(f_name, input_path):
    if f_name.split(".")[1] in ["zip", "shp", "gdb", "shx", "xsd", "dbf", "sbn", "prj", "cpg", "spx", "sbx"]:
        return False

    elif path.basename(input_path).split("-")[1] + "_adds" == f_name.split(".")[0]:
        return False

    else:
        return True


def zip_etl_package(input_path, output_path):
    zip_file_name = path.basename(input_path).split(".")[0] + ".zip"

    zip_file = ZipFile(path.join(output_path, zip_file_name), "w")

    for f in listdir(input_path):
        if include_file(f, input_path):
            zip_file.write(path.join(input_path, f), f, ZIP_DEFLATED)
    zip_file.close()


def parse_gml_for_terminal_coords(inputpath):
    tree = ElementTree()
    tree.parse(inputpath)
    original_geoms = dict()
    terminal_coords = dict()

    geoms = tree.findall('.//{http://ogr.maptools.org/}featureMember')
    for g in geoms:
        original_geoms[g[0][2].text] = g[0][1][0][0].text

    for k, v in original_geoms.iteritems():
        gml_geom = v
        parsed_geom = gml_geom.split()
        begin_x = parsed_geom[0]
        begin_y = parsed_geom[1]
        end_x = parsed_geom[-3]
        end_y = parsed_geom[-2]

        terminal_coords[k] = {'begin_lng': begin_x, 'begin_lat': begin_y, 'end_lng': end_x, 'end_lat': end_y}

    return terminal_coords


# Additional helper functions for geometry
def return_truncated_coord(c):
    coord_elements = str(c).split(".")
    if len(coord_elements[1]) >= 8:
        precision_count = 8
    else:
        precision_count = len(coord_elements[1])
    truncated_coord = "{0}.{1}".format(coord_elements[0], coord_elements[1][:precision_count])
    return truncated_coord


def get_first_x(feat):
    first_x = return_truncated_coord(feat.firstPoint.X)
    return first_x


def get_first_y(feat):
    first_y = return_truncated_coord(feat.firstPoint.Y)
    return first_y


def get_last_x(feat):
    last_x = return_truncated_coord(feat.lastPoint.X)
    return last_x


def get_last_y(feat):
    last_y = return_truncated_coord(feat.lastPoint.Y)
    return last_y


def get_first_m(feat):
    return return_truncated_coord(feat.firstPoint.M)


def get_last_m(feat):
    return return_truncated_coord(feat.lastPoint.M)


def validate_xml(xsd_path, xml_doc):
    """
    Validates the xml against xsd

    :param xml_doc: xml file created by script process
    :param xsd_path: path to the xsd for validation
    """
    xsd_doc = etree.parse(xsd_path)
    xsd = etree.XMLSchema(xsd_doc)
    xml = etree.parse(xml_doc)
    if not xsd.validate(xml):
        return xsd.error_log
        # sys.exit(0)  # TODO Replace with log call
    else:
        return True


def cleanup_directory(folder_path):
    """
    Removes temp files after a successful packet run

    :param folder_path: folder path to clean
    """
    shutil.rmtree(folder_path)


# Custom Exceptions
class InvalidOldGIDList(Exception):
    def __init__(self, l1, l2, l3):
        self.l1 = l1
        self.l2 = l2
        self.l3 = l3

    def __str__(self):
        msg = "The list of OGEOMS for GID={0} contains GID values not present in 'Retire' tasks. {1} != {2}".format(
            self.l1, self.l2, self.l3)
        return repr(msg)


class InvalidOldGIDListFormatting(Exception):
    def __init__(self, l1):
        self.l1 = l1

    def __str__(self):
        msg = "There is an error with the formatting of the value in the OGEOMS field for GID={0}.".format(self.l1)
        return repr(msg)
